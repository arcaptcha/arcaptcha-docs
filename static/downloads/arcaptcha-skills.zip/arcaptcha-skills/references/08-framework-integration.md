# Framework Integration

ARCaptcha is a browser-side JavaScript widget. Framework integrations should respect the framework's DOM lifecycle instead of rendering the widget before its container exists.

## General rules

1. Load the ARCaptcha API script once per page/application shell where possible.
2. Render only after the target element exists.
3. Avoid rendering repeatedly during normal state updates.
4. Store the widget ID in a ref/state variable when programmatic control is needed.
5. Use `reset()` when the application needs to restart the widget.
6. Send the token to the backend and verify it server-side.

## React

Prefer a `useEffect` for explicit rendering when the container is mounted.

```jsx
import { useEffect, useRef } from "react";

export function Captcha({ siteKey, onToken }) {
  const containerRef = useRef(null);
  const widgetIdRef = useRef(null);

  useEffect(() => {
    if (!window.arcaptcha || !containerRef.current) return;

    widgetIdRef.current = window.arcaptcha.render(containerRef.current, {
      site_key: siteKey,
      callback: onToken,
    });

    return () => {
      // Do not invent a destroy API. Clear your own reference.
      widgetIdRef.current = null;
    };
  }, [siteKey, onToken]);

  return <div ref={containerRef} />;
}
```

Important: the exact callback parameter behavior should match the current widget API. If a project uses global callback names rather than function references, follow that project's existing integration pattern.

Load the script in the application's document/head mechanism, not repeatedly inside a component.

## Vue

Use `onMounted()` for explicit rendering:

```vue
<script setup>
import { onMounted, ref } from "vue";

const container = ref(null);
let widgetId = null;

onMounted(() => {
  if (!window.arcaptcha || !container.value) return;

  widgetId = window.arcaptcha.render(container.value, {
    site_key: import.meta.env.VITE_ARCAPTCHA_SITE_KEY
  });
});
</script>

<template>
  <div ref="container"></div>
</template>
```

Do not place the secret key in `VITE_*` variables or any other client-exposed variable.

## Next.js

ARCaptcha is browser-side code, so explicit rendering must occur in a Client Component or equivalent browser-only lifecycle.

```jsx
"use client";

import { useEffect, useRef } from "react";

export default function Captcha({ siteKey }) {
  const ref = useRef(null);

  useEffect(() => {
    if (!window.arcaptcha || !ref.current) return;

    window.arcaptcha.render(ref.current, {
      site_key: siteKey
    });
  }, [siteKey]);

  return <div ref={ref} />;
}
```

Load the ARCaptcha script through the project's preferred Next.js script/document mechanism. Do not import browser-only code into server components.

## Framework-specific warning

Do not assume that React/Vue/Next.js needs a third-party ARCaptcha wrapper. Prefer the documented ARCaptcha browser API unless the project already depends on an official or maintained integration package.
