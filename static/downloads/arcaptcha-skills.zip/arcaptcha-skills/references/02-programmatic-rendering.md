# Programmatic Rendering

Use this reference when the application needs explicit control over the ARCaptcha widget, such as dynamic rendering, multiple widgets, or programmatic execution.

**## Explicit rendering**

Use `arcaptcha.render()` to create a widget programmatically:

````js
const widgetId = arcaptcha.render("#captcha-1", {
  site_key: "YOUR_SITE_KEY",
});

Example:

```html
<script
  src="https://nwidget.arcaptcha.ir/1/api.js?onload=onArcaptchaLoad"
  async
  defer
></script>

<div id="captcha-1"></div>

<script>
  let widgetId;

  function onArcaptchaLoad() {
    widgetId = arcaptcha.render("captcha-1", {
      site_key: "YOUR_SITE_KEY",
    });
  }
</script>
````

Use the documented loading/onload mechanism for the ARCaptcha version used by the project. Do not invent loader parameters.

## Multiple widgets

When multiple CAPTCHA widgets exist, keep each returned widget ID:

```js
const loginWidget = arcaptcha.render("#login-captcha", {
  site_key: "YOUR_SITE_KEY",
});

const signupWidget = arcaptcha.render("#signup-captcha", {
  site_key: "YOUR_SITE_KEY",
});
```

## Programmatic execution

Use `arcaptcha.execute()` when the user explicitly requests programmatic execution or an invisible CAPTCHA triggered by application logic.

```js
async function verifyBeforeSubmit() {
  try {
    const { arcaptcha_token } = await arcaptcha.execute(widgetId);

    await fetch("/api/submit", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        "arcaptcha-token": arcaptcha_token,
      }),
    });
  } catch (error) {
    console.error("ARCaptcha failed:", error);
  }
}
```

When `execute()` returns a token, use that returned token for the backend request.

Do not use `getArcToken()` unnecessarily after `execute()`.

## Token handling

For a widget that has already been completed, the current token can be retrieved with:

```js
const token = arcaptcha.getArcToken(widgetId);
```

For custom API/AJAX requests, send the token explicitly:

```js
{
  "arcaptcha-token": token
}
```

Do not rename the frontend parameter to `challengeId`.

The application backend should read `arcaptcha-token` and send its value to the ARCaptcha verification API as `challenge_id`.

For complete integrations, never stop at obtaining or logging the token. Send it to the backend and perform server-side verification before the protected operation.

See `07-server-verification.md`.

## SPA lifecycle

For React, Vue, or other SPA applications:

- Render after the target element exists.
- Do not render repeatedly on every state update.
- Keep the widget ID in component state/ref as appropriate.
- Reset or recreate the widget when required by the form lifecycle.
- Clean up application-level references when the component is destroyed.

See `08-framework-integration.md`.

## When to use programmatic rendering

Prefer programmatic rendering when:

- The form is mounted dynamically.
- Multiple CAPTCHA instances need separate widget IDs.
- The widget should be rendered explicitly.
- The application needs `render()`, `execute()`, or `reset()`.
- The user explicitly asks for programmatic CAPTCHA control.

Do not use programmatic rendering merely to make a simple static form more complicated.

## Integration priority

Always choose the simplest integration that satisfies the user's request:

- **"Add ARCaptcha" / "Add CAPTCHA"** → use the automatic `.arcaptcha` widget.
- **"Add invisible CAPTCHA"** → use the invisible CAPTCHA integration.
- **"Add programmatic ARCaptcha"** → use `arcaptcha.render()`.
- **"Execute CAPTCHA on submit/button click"** → use `arcaptcha.execute(widgetId)`.
- **"Use widget methods/control the widget"** → use programmatic rendering and the required widget methods.

Regardless of the frontend integration method, protected operations must send the CAPTCHA token to the backend and perform server-side verification.

Never expose the ARCaptcha secret key in client-side code.
