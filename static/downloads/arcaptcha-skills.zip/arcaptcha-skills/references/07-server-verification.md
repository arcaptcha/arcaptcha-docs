# Server-Side Verification

Server-side verification is required before trusting an ARCaptcha result for a protected action.

## Endpoint

```text
POST https://api.arcaptcha.co/arcaptcha/api/verify
```

## Required JSON parameters

```json
{
  "secret_key": "YOUR_SECRET_KEY",
  "challenge_id": "ARCAPTCHA_TOKEN",
  "site_key": "YOUR_SITE_KEY"
}
```

The frontend's `arcaptcha-token` becomes the `challenge_id` sent to the verification API.

## Backend Examples

### Node.js with fetch

```js
const response = await fetch("https://api.arcaptcha.co/arcaptcha/api/verify", {
  method: "POST",
  headers: {
    "Content-Type": "application/json"
  },
  body: JSON.stringify({
    secret_key: process.env.ARCAPTCHA_SECRET_KEY,
    challenge_id: arcaptchaToken,
    site_key: process.env.ARCAPTCHA_SITE_KEY
  })
});

const result = await response.json();

if (!result.success) {
  return reply.code(400).send({ error: "CAPTCHA verification failed" });
}

// Protected business logic starts here.
```

### Node.js with axios

```js
const axios = require('axios');

try {
  const result = await axios.post('https://api.arcaptcha.co/arcaptcha/api/verify', {
    challenge_id: req.body['arcaptcha-token'],
    site_key: process.env.ARCAPTCHA_SITE_KEY,
    secret_key: process.env.ARCAPTCHA_SECRET_KEY
  }, {
    headers: {
      'Content-Type': 'application/json'
    }
  });

  if (!result.data.success) {
    return res.status(400).json({ 
      error: 'CAPTCHA verification failed',
      codes: result.data['error-codes']
    });
  }

  // Protected business logic
} catch (error) {
  console.error('ARCaptcha verification error:', error);
  return res.status(500).json({ error: 'Verification service unavailable' });
}
```

### Python with requests

```python
import requests
import os

def verify_arcaptcha(token):
    url = 'https://api.arcaptcha.co/arcaptcha/api/verify'
    
    payload = {
        'challenge_id': token,
        'site_key': os.getenv('ARCAPTCHA_SITE_KEY'),
        'secret_key': os.getenv('ARCAPTCHA_SECRET_KEY')
    }
    
    headers = {
        'Content-Type': 'application/json'
    }
    
    try:
        response = requests.post(url, json=payload, headers=headers, timeout=10)
        result = response.json()
        
        if not result.get('success'):
            error_codes = result.get('error-codes', [])
            print(f'ARCaptcha verification failed: {error_codes}')
            return False
            
        return True
        
    except requests.exceptions.RequestException as e:
        print(f'ARCaptcha verification error: {e}')
        return False

# Usage in Flask route
@app.route('/signup', methods=['POST'])
def signup():
    token = request.form.get('arcaptcha-token')
    
    if not token:
        return jsonify({'error': 'CAPTCHA token missing'}), 400
    
    if not verify_arcaptcha(token):
        return jsonify({'error': 'CAPTCHA verification failed'}), 400
    
    # Protected business logic
    return jsonify({'success': True}), 200
```

### PHP

```php
<?php
function verifyArcaptcha($token) {
    $url = 'https://api.arcaptcha.co/arcaptcha/api/verify';
    
    $data = array(
        'challenge_id' => $token,
        'site_key' => getenv('ARCAPTCHA_SITE_KEY'),
        'secret_key' => getenv('ARCAPTCHA_SECRET_KEY')
    );
    
    $options = array(
        'http' => array(
            'header'  => "Content-Type: application/json\r\n",
            'method'  => 'POST',
            'content' => json_encode($data),
            'timeout' => 10
        )
    );
    
    $context = stream_context_create($options);
    $result = @file_get_contents($url, false, $context);
    
    if ($result === false) {
        error_log('ARCaptcha verification request failed');
        return false;
    }
    
    $response = json_decode($result, true);
    
    if (!isset($response['success']) || !$response['success']) {
        $errors = isset($response['error-codes']) ? $response['error-codes'] : [];
        error_log('ARCaptcha verification failed: ' . implode(', ', $errors));
        return false;
    }
    
    return true;
}

// Usage
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['arcaptcha-token'] ?? '';
    
    if (empty($token)) {
        http_response_code(400);
        echo json_encode(['error' => 'CAPTCHA token missing']);
        exit;
    }
    
    if (!verifyArcaptcha($token)) {
        http_response_code(400);
        echo json_encode(['error' => 'CAPTCHA verification failed']);
        exit;
    }
    
    // Protected business logic
    echo json_encode(['success' => true]);
}
?>
```

### Go

```go
package main

import (
    "bytes"
    "encoding/json"
    "fmt"
    "io"
    "net/http"
    "os"
    "time"
)

type VerifyRequest struct {
    ChallengeID string `json:"challenge_id"`
    SiteKey     string `json:"site_key"`
    SecretKey   string `json:"secret_key"`
}

type VerifyResponse struct {
    Success    bool     `json:"success"`
    ErrorCodes []string `json:"error-codes,omitempty"`
}

func verifyArcaptcha(token string) (bool, error) {
    url := "https://api.arcaptcha.co/arcaptcha/api/verify"
    
    payload := VerifyRequest{
        ChallengeID: token,
        SiteKey:     os.Getenv("ARCAPTCHA_SITE_KEY"),
        SecretKey:   os.Getenv("ARCAPTCHA_SECRET_KEY"),
    }
    
    jsonData, err := json.Marshal(payload)
    if err != nil {
        return false, fmt.Errorf("failed to marshal request: %w", err)
    }
    
    client := &http.Client{Timeout: 10 * time.Second}
    req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
    if err != nil {
        return false, fmt.Errorf("failed to create request: %w", err)
    }
    
    req.Header.Set("Content-Type", "application/json")
    
    resp, err := client.Do(req)
    if err != nil {
        return false, fmt.Errorf("request failed: %w", err)
    }
    defer resp.Body.Close()
    
    body, err := io.ReadAll(resp.Body)
    if err != nil {
        return false, fmt.Errorf("failed to read response: %w", err)
    }
    
    var result VerifyResponse
    if err := json.Unmarshal(body, &result); err != nil {
        return false, fmt.Errorf("failed to parse response: %w", err)
    }
    
    if !result.Success {
        return false, fmt.Errorf("verification failed: %v", result.ErrorCodes)
    }
    
    return true, nil
}

// Usage in HTTP handler
func signupHandler(w http.ResponseWriter, r *http.Request) {
    if r.Method != http.MethodPost {
        http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
        return
    }
    
    token := r.FormValue("arcaptcha-token")
    if token == "" {
        http.Error(w, "CAPTCHA token missing", http.StatusBadRequest)
        return
    }
    
    verified, err := verifyArcaptcha(token)
    if err != nil || !verified {
        http.Error(w, "CAPTCHA verification failed", http.StatusBadRequest)
        return
    }
    
    // Protected business logic
    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(map[string]bool{"success": true})
}
```

Adapt the response handling to the project's backend framework.

## Environment variables

A typical server setup is:

```text
ARCAPTCHA_SITE_KEY=...
ARCAPTCHA_SECRET_KEY=...
```

Only the secret must be server-only. A site key may be exposed to the client, but keeping a single configured source of truth is often useful.

## Verification error codes

The verify endpoint may return these error codes in the `error-codes` array:

- `missing-input-sitekey` - The site_key parameter is missing
- `missing-input-secret` - The secret_key parameter is missing
- `missing-input-response` - The challenge_id is missing
- `bad-request` - The request is invalid or malformed
- `invalid-input-sitekey` - The site_key is invalid or malformed
- `invalid-input-secret` - The secret_key is invalid or malformed
- `invalid-input-response` - The challenge_id is invalid or malformed
- `timeout-or-duplicate` - The token has expired or was already used

Always check the `success` field first. Only when `success === false` should you inspect `error-codes`.

## Verification rules

- Reject missing tokens.
- Send the expected site key.
- Never log the secret key.
- Avoid logging full CAPTCHA tokens in production.
- Treat verification errors as failures for the protected operation.
- Check `success === true` before continuing.
- Tokens are single-use and should be verified promptly (within a few minutes).
- Handle network failures gracefully - fail closed (deny access).
- Consider implementing retry logic for network errors (not for invalid tokens).
- Rate-limit verification requests to prevent abuse.

## Common architecture

```text
Browser
  │
  │ ARCaptcha
  ▼
arcaptcha-token
  │
  │ application request
  ▼
Your Backend
  │
  │ secret_key + site_key + challenge_id
  ▼
ARCaptcha Verify API
  │
  │ success
  ▼
Your protected operation
```
