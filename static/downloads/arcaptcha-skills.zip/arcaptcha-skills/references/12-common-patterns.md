# Common Patterns

This reference covers common integration patterns and real-world use cases for ARCaptcha.

## Multi-Step Forms

### Pattern: CAPTCHA on final step only

Verify the user once at the end of a multi-step form rather than on every step.

**Step 1-2: Collect data without CAPTCHA**
```html
<!-- Step 1 -->
<form id="step1">
  <input name="email" type="email" required />
  <button type="button" onclick="goToStep2()">Next</button>
</form>

<!-- Step 2 -->
<form id="step2" style="display: none;">
  <input name="phone" type="tel" required />
  <button type="button" onclick="goToStep3()">Next</button>
</form>
```

**Step 3: Add CAPTCHA before final submission**
```html
<!-- Step 3 with CAPTCHA -->
<form id="step3" style="display: none;" onsubmit="handleFinalSubmit(event)">
  <input name="address" type="text" required />
  
  <div class="arcaptcha" data-site-key="YOUR_SITE_KEY" data-callback="onCaptchaSuccess"></div>
  
  <button type="submit">Complete Registration</button>
</form>

<script>
let captchaToken = null;

function onCaptchaSuccess(token) {
  captchaToken = token;
}

function handleFinalSubmit(event) {
  event.preventDefault();
  
  if (!captchaToken) {
    alert('Please complete the security check');
    return;
  }
  
  // Collect all form data from previous steps
  const formData = {
    email: document.querySelector('#step1 input[name="email"]').value,
    phone: document.querySelector('#step2 input[name="phone"]').value,
    address: document.querySelector('#step3 input[name="address"]').value,
    'arcaptcha-token': captchaToken
  };
  
  // Submit to backend
  submitForm(formData);
}
</script>
```

### Pattern: Reset on step back

If users can navigate backward in multi-step forms, reset the CAPTCHA when they return:

```javascript
let widgetId;

function initCaptcha() {
  widgetId = arcaptcha.render('captcha-container', {
    site_key: 'YOUR_SITE_KEY',
    callback: onCaptchaSuccess
  });
}

function goToPreviousStep() {
  // Reset CAPTCHA when going back
  if (widgetId) {
    arcaptcha.reset(widgetId);
    captchaToken = null;
  }
  
  // Show previous step
  showStep(currentStep - 1);
}
```

## AJAX Form Submissions

### Pattern: Submit with AJAX after CAPTCHA

Prevent default form submission and use AJAX:

```html
<form id="contact-form">
  <input name="name" type="text" required />
  <input name="email" type="email" required />
  <textarea name="message" required></textarea>
  
  <div class="arcaptcha" data-site-key="YOUR_SITE_KEY"></div>
  
  <button type="submit">Send Message</button>
</form>

<script>
document.getElementById('contact-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const formData = new FormData(e.target);
  const token = formData.get('arcaptcha-token');
  
  if (!token) {
    alert('Please complete the security check');
    return;
  }
  
  try {
    const response = await fetch('/api/contact', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: formData.get('name'),
        email: formData.get('email'),
        message: formData.get('message'),
        'arcaptcha-token': token
      })
    });
    
    const result = await response.json();
    
    if (response.ok) {
      alert('Message sent successfully!');
      e.target.reset();
      // Note: CAPTCHA will auto-reset after form reset
    } else {
      alert('Failed to send message: ' + result.error);
      // Reset CAPTCHA to allow retry
      arcaptcha.reset();
    }
  } catch (error) {
    console.error('Submit error:', error);
    alert('Network error. Please try again.');
    arcaptcha.reset();
  }
});
</script>
```

### Pattern: Fetch with invisible CAPTCHA

Execute invisible CAPTCHA before AJAX submission:

```html
<form id="ajax-form">
  <input name="email" type="email" required />
  <button type="submit">Subscribe</button>
</form>

<div id="captcha-container"></div>

<script>
let widgetId;

window.addEventListener('load', () => {
  widgetId = arcaptcha.render('captcha-container', {
    site_key: 'YOUR_SITE_KEY',
    size: 'invisible'
  });
});

document.getElementById('ajax-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const email = e.target.email.value;
  
  try {
    // Execute invisible CAPTCHA
    const { arcaptcha_token } = await arcaptcha.execute(widgetId);
    
    // Submit with token
    const response = await fetch('/api/subscribe', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        email: email,
        'arcaptcha-token': arcaptcha_token
      })
    });
    
    if (response.ok) {
      alert('Subscribed successfully!');
      e.target.reset();
    } else {
      throw new Error('Subscription failed');
    }
  } catch (error) {
    console.error('Error:', error);
    alert('Failed to subscribe. Please try again.');
    arcaptcha.reset(widgetId);
  }
});
</script>
```

## SPA Route Transitions

### Pattern: React route with CAPTCHA

Render CAPTCHA when route/component mounts:

```jsx
import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';

function ContactPage() {
  const captchaRef = useRef(null);
  const widgetIdRef = useRef(null);
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });

  useEffect(() => {
    // Render CAPTCHA when component mounts
    if (window.arcaptcha && captchaRef.current && !widgetIdRef.current) {
      widgetIdRef.current = window.arcaptcha.render(captchaRef.current, {
        site_key: process.env.REACT_APP_ARCAPTCHA_SITE_KEY
      });
    }

    // Cleanup on unmount
    return () => {
      if (widgetIdRef.current) {
        // Clear reference (no destroy API)
        widgetIdRef.current = null;
      }
    };
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const token = window.arcaptcha.getArcToken(widgetIdRef.current);
    
    if (!token) {
      alert('Please complete the security check');
      return;
    }

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          'arcaptcha-token': token
        })
      });

      if (response.ok) {
        navigate('/thank-you');
      } else {
        alert('Submission failed');
        window.arcaptcha.reset(widgetIdRef.current);
      }
    } catch (error) {
      console.error(error);
      window.arcaptcha.reset(widgetIdRef.current);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        value={formData.name}
        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
        required
      />
      <div ref={captchaRef} />
      <button type="submit">Submit</button>
    </form>
  );
}
```

### Pattern: Vue router with CAPTCHA

```vue
<template>
  <div>
    <form @submit.prevent="handleSubmit">
      <input v-model="email" type="email" required />
      <div ref="captchaContainer"></div>
      <button type="submit">Submit</button>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      email: '',
      widgetId: null
    };
  },
  
  mounted() {
    // Render CAPTCHA when route loads
    if (window.arcaptcha && this.$refs.captchaContainer) {
      this.widgetId = window.arcaptcha.render(this.$refs.captchaContainer, {
        site_key: process.env.VUE_APP_ARCAPTCHA_SITE_KEY
      });
    }
  },
  
  beforeUnmount() {
    // Clear reference on route change
    this.widgetId = null;
  },
  
  methods: {
    async handleSubmit() {
      const token = window.arcaptcha.getArcToken(this.widgetId);
      
      if (!token) {
        alert('Please complete the security check');
        return;
      }
      
      try {
        const response = await fetch('/api/submit', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: this.email,
            'arcaptcha-token': token
          })
        });
        
        if (response.ok) {
          this.$router.push('/success');
        } else {
          window.arcaptcha.reset(this.widgetId);
        }
      } catch (error) {
        console.error(error);
        window.arcaptcha.reset(this.widgetId);
      }
    }
  }
};
</script>
```

## Error Recovery

### Pattern: Retry with reset

Allow users to retry after errors:

```javascript
async function submitWithCaptcha(formData, token) {
  try {
    const response = await fetch('/api/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...formData,
        'arcaptcha-token': token
      })
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Submission failed');
    }
    
    return await response.json();
  } catch (error) {
    console.error('Submission error:', error);
    throw error;
  }
}

async function handleFormSubmit(event) {
  event.preventDefault();
  
  const formData = collectFormData(event.target);
  const token = arcaptcha.getArcToken();
  
  if (!token) {
    showError('Please complete the security check');
    return;
  }
  
  try {
    await submitWithCaptcha(formData, token);
    showSuccess('Submitted successfully!');
    event.target.reset();
  } catch (error) {
    // Reset CAPTCHA to allow retry
    arcaptcha.reset();
    
    // Show user-friendly error
    if (error.message.includes('CAPTCHA')) {
      showError('Security verification failed. Please try again.');
    } else if (error.message.includes('network')) {
      showError('Network error. Please check your connection and try again.');
    } else {
      showError('Submission failed. Please try again.');
    }
  }
}
```

### Pattern: Graceful degradation

Handle CAPTCHA loading failures:

```javascript
let captchaLoaded = false;
let captchaRequired = true;

// Check if script loaded
window.addEventListener('load', () => {
  captchaLoaded = typeof window.arcaptcha !== 'undefined';
  
  if (!captchaLoaded) {
    console.warn('ARCaptcha failed to load');
    
    // Option 1: Show warning
    document.getElementById('captcha-warning').style.display = 'block';
    
    // Option 2: Disable form
    // document.getElementById('submit-btn').disabled = true;
    
    // Option 3: Allow submission without CAPTCHA (not recommended for production)
    // captchaRequired = false;
  }
});

async function handleSubmit(event) {
  event.preventDefault();
  
  let token = null;
  
  if (captchaRequired && captchaLoaded) {
    token = arcaptcha.getArcToken();
    
    if (!token) {
      alert('Please complete the security check');
      return;
    }
  }
  
  // Submit with or without token based on configuration
  await submitForm({ ...formData, 'arcaptcha-token': token });
}
```

### Pattern: Timeout handling

Handle slow CAPTCHA responses:

```javascript
function executeCaptchaWithTimeout(widgetId, timeoutMs = 30000) {
  return Promise.race([
    arcaptcha.execute(widgetId),
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error('CAPTCHA timeout')), timeoutMs)
    )
  ]);
}

async function handleSubmit(event) {
  event.preventDefault();
  
  try {
    const { arcaptcha_token } = await executeCaptchaWithTimeout(widgetId);
    
    // Submit with token
    await submitForm(arcaptcha_token);
  } catch (error) {
    if (error.message === 'CAPTCHA timeout') {
      alert('Security check timed out. Please try again.');
      arcaptcha.reset(widgetId);
    } else {
      alert('An error occurred. Please try again.');
      arcaptcha.reset(widgetId);
    }
  }
}
```

## Conditional CAPTCHA

### Pattern: Show CAPTCHA after failed attempts

Only require CAPTCHA after suspicious activity:

```javascript
let failedAttempts = 0;
const MAX_ATTEMPTS = 3;
let widgetId = null;

async function handleLogin(event) {
  event.preventDefault();
  
  const username = event.target.username.value;
  const password = event.target.password.value;
  
  let captchaToken = null;
  
  // Require CAPTCHA after failed attempts
  if (failedAttempts >= MAX_ATTEMPTS) {
    if (!widgetId) {
      // Render CAPTCHA dynamically
      widgetId = arcaptcha.render('captcha-container', {
        site_key: 'YOUR_SITE_KEY'
      });
      document.getElementById('captcha-container').style.display = 'block';
    }
    
    captchaToken = arcaptcha.getArcToken(widgetId);
    
    if (!captchaToken) {
      alert('Please complete the security check');
      return;
    }
  }
  
  try {
    const response = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username,
        password,
        'arcaptcha-token': captchaToken
      })
    });
    
    if (response.ok) {
      // Success - reset counter
      failedAttempts = 0;
      window.location.href = '/dashboard';
    } else {
      // Failed - increment counter
      failedAttempts++;
      
      if (widgetId) {
        arcaptcha.reset(widgetId);
      }
      
      alert('Login failed. Please try again.');
    }
  } catch (error) {
    console.error(error);
    if (widgetId) {
      arcaptcha.reset(widgetId);
    }
  }
}
```

## Modal/Dialog Forms

### Pattern: CAPTCHA in modal

Render CAPTCHA when modal opens:

```javascript
let modalWidgetId = null;

function openModal() {
  document.getElementById('modal').style.display = 'block';
  
  // Render CAPTCHA when modal opens
  if (!modalWidgetId) {
    modalWidgetId = arcaptcha.render('modal-captcha', {
      site_key: 'YOUR_SITE_KEY',
      callback: onModalCaptchaSuccess
    });
  }
}

function closeModal() {
  document.getElementById('modal').style.display = 'none';
  
  // Reset CAPTCHA when modal closes
  if (modalWidgetId) {
    arcaptcha.reset(modalWidgetId);
  }
}

function onModalCaptchaSuccess(token) {
  // Handle token
  submitModalForm(token);
}
```

### Pattern: React Modal with CAPTCHA

```jsx
import { useEffect, useRef, useState } from 'react';

function FormModal({ isOpen, onClose }) {
  const captchaRef = useRef(null);
  const widgetIdRef = useRef(null);

  useEffect(() => {
    // Render CAPTCHA when modal opens
    if (isOpen && window.arcaptcha && captchaRef.current && !widgetIdRef.current) {
      widgetIdRef.current = window.arcaptcha.render(captchaRef.current, {
        site_key: process.env.REACT_APP_ARCAPTCHA_SITE_KEY
      });
    }

    // Reset when modal closes
    if (!isOpen && widgetIdRef.current) {
      window.arcaptcha.reset(widgetIdRef.current);
    }
  }, [isOpen]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const token = window.arcaptcha.getArcToken(widgetIdRef.current);
    
    if (!token) {
      alert('Please complete the security check');
      return;
    }

    // Submit form
    await submitForm(token);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="modal">
      <form onSubmit={handleSubmit}>
        <input type="email" required />
        <div ref={captchaRef} />
        <button type="submit">Submit</button>
        <button type="button" onClick={onClose}>Cancel</button>
      </form>
    </div>
  );
}
```

## Rate Limiting Integration

### Pattern: Backend rate limiting with CAPTCHA

Combine rate limiting with CAPTCHA for enhanced security:

```javascript
// Backend (Express example)
const rateLimit = require('express-rate-limit');

// Standard rate limit
const standardLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // 100 requests per window
});

// Strict rate limit for protected endpoints
const strictLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5 // 5 requests per window
});

app.post('/api/login',
  standardLimiter,
  async (req, res) => {
    const { username, password, 'arcaptcha-token': token } = req.body;
    
    // Always verify CAPTCHA for login attempts
    const captchaValid = await verifyArcaptcha(token);
    
    if (!captchaValid) {
      return res.status(400).json({ error: 'CAPTCHA verification failed' });
    }
    
    // Proceed with login
    const user = await authenticateUser(username, password);
    
    if (user) {
      res.json({ success: true, user });
    } else {
      res.status(401).json({ error: 'Invalid credentials' });
    }
  }
);

app.post('/api/password-reset',
  strictLimiter, // Stricter limits for sensitive operations
  async (req, res) => {
    const { email, 'arcaptcha-token': token } = req.body;
    
    const captchaValid = await verifyArcaptcha(token);
    
    if (!captchaValid) {
      return res.status(400).json({ error: 'CAPTCHA verification failed' });
    }
    
    // Send password reset email
    await sendPasswordResetEmail(email);
    res.json({ success: true });
  }
);
```

## Best Practices Summary

1. **Reset on error**: Always reset CAPTCHA after failed submissions to allow retry
2. **Single-use tokens**: Never reuse tokens; get a fresh token for each attempt
3. **User feedback**: Provide clear error messages when CAPTCHA fails
4. **Graceful degradation**: Handle CAPTCHA loading failures
5. **SPA lifecycle**: Render CAPTCHA on mount, clean up on unmount
6. **Multi-step forms**: Place CAPTCHA on final step to reduce friction
7. **AJAX forms**: Prevent default submission, use AJAX with token
8. **Timeouts**: Handle slow or hung CAPTCHA responses
9. **Conditional logic**: Show CAPTCHA only when needed (after failed attempts)
10. **Backend verification**: Always verify tokens server-side
