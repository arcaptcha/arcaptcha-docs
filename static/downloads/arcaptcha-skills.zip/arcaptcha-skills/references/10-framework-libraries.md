# Framework Libraries

ARCaptcha provides official and community-maintained libraries for popular frameworks and platforms. Use these when available to simplify integration and follow framework-specific best practices.

## When to use framework libraries

Prefer official libraries when:
- The project already uses the framework ecosystem
- You want framework-specific component abstractions
- The library is actively maintained and matches the ARCaptcha version
- The team prefers declarative component usage over imperative API calls

Use the browser API directly when:
- No official library exists for the framework
- The library is outdated or unmaintained
- You need fine-grained control over widget lifecycle
- The integration is simple enough that a library adds unnecessary complexity

## Frontend Framework Libraries

### React

**Package:** `arcaptcha-react`

**Installation:**
```bash
npm install arcaptcha-react
```

**Usage:**
```jsx
import { Arcaptcha } from 'arcaptcha-react';

function MyForm() {
  const handleToken = (token) => {
    console.log('ARCaptcha token:', token);
    // Send token to backend
  };

  return (
    <form>
      <input type="email" name="email" required />
      
      <Arcaptcha
        sitekey="YOUR_SITE_KEY"
        callback={handleToken}
        theme="dark"
        lang="en"
      />
      
      <button type="submit">Submit</button>
    </form>
  );
}
```

**Available props:**
- `sitekey` (required): Your site key
- `callback`: Function called on success with token
- `theme`: 'light' or 'dark'
- `lang`: 'en', 'fa', etc.
- `color`: Widget color (hex or name)
- `size`: 'normal' or 'invisible'
- All other configuration options from the browser API

### Vue 2

**Package:** `arcaptcha-vue`

**Installation:**
```bash
npm install arcaptcha-vue
```

**Usage:**
```vue
<template>
  <form @submit.prevent="handleSubmit">
    <input v-model="email" type="email" required />
    
    <arcaptcha
      :site-key="siteKey"
      :callback="onToken"
      theme="dark"
      lang="en"
    />
    
    <button type="submit">Submit</button>
  </form>
</template>

<script>
import Arcaptcha from 'arcaptcha-vue';

export default {
  components: { Arcaptcha },
  data() {
    return {
      siteKey: 'YOUR_SITE_KEY',
      email: ''
    };
  },
  methods: {
    onToken(token) {
      console.log('ARCaptcha token:', token);
    },
    handleSubmit() {
      // Submit form with token
    }
  }
};
</script>
```

### Vue 3

**Package:** `arcaptcha-vue3`

**Installation:**
```bash
npm install arcaptcha-vue3
```

**Usage:**
```vue
<script setup>
import { ref } from 'vue';
import Arcaptcha from 'arcaptcha-vue3';

const siteKey = 'YOUR_SITE_KEY';
const email = ref('');

function onToken(token) {
  console.log('ARCaptcha token:', token);
}

function handleSubmit() {
  // Submit form with token
}
</script>

<template>
  <form @submit.prevent="handleSubmit">
    <input v-model="email" type="email" required />
    
    <Arcaptcha
      :site-key="siteKey"
      :callback="onToken"
      theme="dark"
    />
    
    <button type="submit">Submit</button>
  </form>
</template>
```

### Angular

**Package:** `arcaptcha-angular`

**Installation:**
```bash
npm install arcaptcha-angular
```

**Module setup:**
```typescript
import { NgModule } from '@angular/core';
import { ArcaptchaModule } from 'arcaptcha-angular';

@NgModule({
  imports: [
    ArcaptchaModule.forRoot({
      siteKey: 'YOUR_SITE_KEY'
    })
  ]
})
export class AppModule { }
```

**Component usage:**
```typescript
import { Component } from '@angular/core';

@Component({
  selector: 'app-form',
  template: `
    <form (ngSubmit)="onSubmit()">
      <input type="email" [(ngModel)]="email" required />
      
      <arcaptcha
        [siteKey]="siteKey"
        (callback)="onToken($event)"
        theme="dark"
      ></arcaptcha>
      
      <button type="submit">Submit</button>
    </form>
  `
})
export class FormComponent {
  siteKey = 'YOUR_SITE_KEY';
  email = '';

  onToken(token: string) {
    console.log('ARCaptcha token:', token);
  }

  onSubmit() {
    // Submit form with token
  }
}
```

### Flutter

**Package:** `arcaptcha_flutter`

**Installation (pubspec.yaml):**
```yaml
dependencies:
  arcaptcha_flutter: ^latest_version
```

**Usage:**
```dart
import 'package:flutter/material.dart';
import 'package:arcaptcha_flutter/arcaptcha_flutter.dart';

class MyForm extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          TextField(
            decoration: InputDecoration(labelText: 'Email'),
          ),
          Arcaptcha(
            siteKey: 'YOUR_SITE_KEY',
            onTokenReceived: (token) {
              print('ARCaptcha token: $token');
              // Submit form with token
            },
            theme: ArcaptchaTheme.dark,
            lang: 'en',
          ),
          ElevatedButton(
            onPressed: () {
              // Handle submit
            },
            child: Text('Submit'),
          ),
        ],
      ),
    );
  }
}
```

## Backend SDK Libraries

Backend SDKs simplify server-side token verification by handling API requests, error handling, and response parsing.

### Node.js

**Package:** `arcaptcha-nodejs`

**Installation:**
```bash
npm install arcaptcha-nodejs
```

**Usage:**
```javascript
const Arcaptcha = require('arcaptcha-nodejs');

const arcaptcha = new Arcaptcha({
  site_key: process.env.ARCAPTCHA_SITE_KEY,
  secret_key: process.env.ARCAPTCHA_SECRET_KEY
});

app.post('/signup', async (req, res) => {
  const token = req.body['arcaptcha-token'];
  
  try {
    const result = await arcaptcha.verify(token);
    
    if (result.success) {
      // Protected business logic
      res.json({ success: true });
    } else {
      res.status(400).json({ error: 'CAPTCHA verification failed' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Verification service error' });
  }
});
```

### PHP

**Package:** `arcaptcha-php`

**Installation (Composer):**
```bash
composer require arcaptcha/arcaptcha-php
```

**Usage:**
```php
<?php
require 'vendor/autoload.php';

use Arcaptcha\Arcaptcha;

$arcaptcha = new Arcaptcha(
    getenv('ARCAPTCHA_SITE_KEY'),
    getenv('ARCAPTCHA_SECRET_KEY')
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['arcaptcha-token'] ?? '';
    
    try {
        $result = $arcaptcha->verify($token);
        
        if ($result->isSuccess()) {
            // Protected business logic
            echo json_encode(['success' => true]);
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'CAPTCHA verification failed']);
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Verification service error']);
    }
}
?>
```

### Python

**Package:** `arcaptcha-python`

**Installation:**
```bash
pip install arcaptcha-python
```

**Usage:**
```python
from arcaptcha import Arcaptcha
import os

arcaptcha = Arcaptcha(
    site_key=os.getenv('ARCAPTCHA_SITE_KEY'),
    secret_key=os.getenv('ARCAPTCHA_SECRET_KEY')
)

@app.route('/signup', methods=['POST'])
def signup():
    token = request.form.get('arcaptcha-token')
    
    try:
        result = arcaptcha.verify(token)
        
        if result.success:
            # Protected business logic
            return jsonify({'success': True}), 200
        else:
            return jsonify({'error': 'CAPTCHA verification failed'}), 400
            
    except Exception as e:
        print(f'Verification error: {e}')
        return jsonify({'error': 'Verification service error'}), 500
```

### Ruby

**Package:** `arcaptcha-ruby`

**Installation (Gemfile):**
```ruby
gem 'arcaptcha-ruby'
```

**Usage:**
```ruby
require 'arcaptcha'

arcaptcha = Arcaptcha::Client.new(
  site_key: ENV['ARCAPTCHA_SITE_KEY'],
  secret_key: ENV['ARCAPTCHA_SECRET_KEY']
)

post '/signup' do
  token = params['arcaptcha-token']
  
  begin
    result = arcaptcha.verify(token)
    
    if result.success?
      # Protected business logic
      { success: true }.to_json
    else
      status 400
      { error: 'CAPTCHA verification failed' }.to_json
    end
  rescue => e
    status 500
    { error: 'Verification service error' }.to_json
  end
end
```

### Go

**Package:** `arcaptcha-go`

**Installation:**
```bash
go get github.com/arcaptcha/arcaptcha-go
```

**Usage:**
```go
package main

import (
    "github.com/arcaptcha/arcaptcha-go"
    "os"
)

func main() {
    client := arcaptcha.NewClient(
        os.Getenv("ARCAPTCHA_SITE_KEY"),
        os.Getenv("ARCAPTCHA_SECRET_KEY"),
    )
    
    http.HandleFunc("/signup", func(w http.ResponseWriter, r *http.Request) {
        token := r.FormValue("arcaptcha-token")
        
        result, err := client.Verify(token)
        if err != nil {
            http.Error(w, "Verification service error", http.StatusInternalServerError)
            return
        }
        
        if !result.Success {
            http.Error(w, "CAPTCHA verification failed", http.StatusBadRequest)
            return
        }
        
        // Protected business logic
        w.Header().Set("Content-Type", "application/json")
        w.Write([]byte(`{"success": true}`))
    })
}
```

### C#

**Package:** `Arcaptcha.CSharp`

**Installation (NuGet):**
```bash
dotnet add package Arcaptcha.CSharp
```

**Usage:**
```csharp
using Arcaptcha;

var client = new ArcaptchaClient(
    Environment.GetEnvironmentVariable("ARCAPTCHA_SITE_KEY"),
    Environment.GetEnvironmentVariable("ARCAPTCHA_SECRET_KEY")
);

[HttpPost("signup")]
public async Task<IActionResult> Signup([FromForm] string arcaptchaToken)
{
    try
    {
        var result = await client.VerifyAsync(arcaptchaToken);
        
        if (result.Success)
        {
            // Protected business logic
            return Ok(new { success = true });
        }
        else
        {
            return BadRequest(new { error = "CAPTCHA verification failed" });
        }
    }
    catch (Exception ex)
    {
        return StatusCode(500, new { error = "Verification service error" });
    }
}
```

### Elixir

**Package:** `arcaptcha-elixir`

**Installation (mix.exs):**
```elixir
defp deps do
  [
    {:arcaptcha, "~> 1.0"}
  ]
end
```

**Usage:**
```elixir
defmodule MyApp.FormController do
  use MyApp, :controller

  def signup(conn, %{"arcaptcha-token" => token}) do
    case Arcaptcha.verify(token) do
      {:ok, %{success: true}} ->
        # Protected business logic
        json(conn, %{success: true})
      
      {:ok, %{success: false}} ->
        conn
        |> put_status(400)
        |> json(%{error: "CAPTCHA verification failed"})
      
      {:error, _reason} ->
        conn
        |> put_status(500)
        |> json(%{error: "Verification service error"})
    end
  end
end
```

## Framework-Specific Integrations

### Laravel

**Package:** `arcaptcha-laravel`

**Installation:**
```bash
composer require arcaptcha/laravel
```

**Configuration (.env):**
```env
ARCAPTCHA_SITE_KEY=your_site_key
ARCAPTCHA_SECRET_KEY=your_secret_key
```

**Validation usage:**
```php
<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SignupController extends Controller
{
    public function store(Request $request)
    {
        $validated = $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:8',
            'arcaptcha-token' => 'required|arcaptcha'
        ]);
        
        // Protected business logic
        return response()->json(['success' => true]);
    }
}
```

### Django

**Package:** `django-arcaptcha`

**Installation:**
```bash
pip install django-arcaptcha
```

**Settings (settings.py):**
```python
INSTALLED_APPS = [
    ...
    'arcaptcha',
]

ARCAPTCHA_SITE_KEY = os.getenv('ARCAPTCHA_SITE_KEY')
ARCAPTCHA_SECRET_KEY = os.getenv('ARCAPTCHA_SECRET_KEY')
```

**Form usage:**
```python
from django import forms
from arcaptcha.fields import ArcaptchaField

class SignupForm(forms.Form):
    email = forms.EmailField()
    password = forms.CharField(widget=forms.PasswordInput)
    captcha = ArcaptchaField()

# View
from django.shortcuts import render
from django.http import JsonResponse

def signup(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            # Protected business logic
            return JsonResponse({'success': True})
        else:
            return JsonResponse({'error': 'Form validation failed'}, status=400)
    
    return render(request, 'signup.html', {'form': form})
```

## CMS Platform Plugins

### WordPress

**Plugin:** ARCaptcha Official Plugin

**Installation:**
1. Download from WordPress plugin directory or ARCaptcha dashboard
2. Upload to `/wp-content/plugins/` or install via WordPress admin
3. Activate the plugin
4. Navigate to Settings → ARCaptcha
5. Enter site key and secret key
6. Enable for desired forms (login, registration, comments, contact forms)

**Features:**
- Protects login, registration, password reset forms
- Comment form protection
- Contact Form 7 integration
- WooCommerce checkout protection
- Custom form integration via shortcode

**Shortcode usage:**
```php
[arcaptcha]
```

### WordPress + Gravity Forms

**Plugin:** ARCaptcha for Gravity Forms (Community)

**Installation:**
1. Install Gravity Forms (required)
2. Install ARCaptcha for Gravity Forms plugin
3. Configure site and secret keys
4. Add ARCaptcha field to forms via form builder

## Library selection guidelines

1. **Check version compatibility**: Ensure library supports ARCaptcha v5.0.0
2. **Review maintenance**: Check last update date and issue resolution
3. **Verify documentation**: Ensure library docs match your use case
4. **Consider bundle size**: Frontend libraries add to bundle - evaluate impact
5. **Fallback plan**: Be prepared to use browser API directly if library has issues
6. **Security updates**: Monitor library for security patches

## When libraries are unavailable or inappropriate

Use the browser API directly as documented in other reference files:
- `01-basic-integration.md` for simple HTML forms
- `02-programmatic-rendering.md` for SPA/dynamic rendering
- `08-framework-integration.md` for custom framework integration patterns

The browser API is the source of truth. Framework libraries are convenience wrappers.
