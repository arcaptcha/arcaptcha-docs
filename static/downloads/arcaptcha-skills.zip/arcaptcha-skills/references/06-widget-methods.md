# Widget Methods

ARCaptcha v5.0.0 exposes methods on the `arcaptcha` object.

## `arcaptcha.render(container, params)`

Renders a widget and returns a unique widget ID.

```js
const widgetId = arcaptcha.render("captcha-1", {
  site_key: "YOUR_SITE_KEY"
});
```

Keep the returned ID when the application has multiple widgets or needs explicit control.

## `arcaptcha.reset(widgetID)`

Resets a widget.

```js
arcaptcha.reset(widgetId);
```

The `widgetID` is optional and defaults to the first widget created. Prefer an explicit ID when multiple widgets exist.

## `arcaptcha.getArcToken(widgetID)`

Gets the current challenge ID/token for a widget.

```js
const token = arcaptcha.getArcToken(widgetId);
```

**Parameters:**
- `widgetID` (optional): The unique widget identifier returned by `render()`. If omitted, defaults to the first widget created.

**Returns:**
- String containing the current ARCaptcha token, or `null` if no token is available

**When to use:**
- AJAX form submissions where you need to retrieve the token programmatically
- Custom form handling that doesn't rely on automatic token insertion
- Multi-widget scenarios where you need tokens from specific widgets

Use this only when programmatic retrieval is actually needed. For a normal form, the automatically inserted `arcaptcha-token` value is often simpler.

## `arcaptcha.execute(widgetID)`

Programmatically triggers the ARCaptcha workflow. Commonly used with invisible CAPTCHA.

```js
arcaptcha.execute(widgetId)
  .then(({ arcaptcha_token }) => {
    // Use token in your request.
  })
  .catch((error) => {
    console.error(error);
  });
```

**Parameters:**
- `widgetID` (optional): The unique widget identifier returned by `render()`. If omitted, defaults to the first widget created.

**Returns:**
- Promise that resolves with `{ arcaptcha_token: string }` on success
- Promise that rejects with error object on failure

**Promise resolution scenarios:**
- **Resolves**: User successfully completes challenge, token is available
- **Rejects**: Network error, server error, user failed challenge, widget not ready, or user closed challenge without completing

**Example with error handling:**
```js
arcaptcha.execute(widgetId)
  .then(({ arcaptcha_token }) => {
    // Submit form with token
    submitForm(arcaptcha_token);
  })
  .catch((error) => {
    // Handle failure gracefully
    console.error('ARCaptcha failed:', error);
    alert('Security verification failed. Please try again.');
    arcaptcha.reset(widgetId); // Reset for retry
  });
```

## Choosing a method

- Need a widget -> `render()`
- Need to clear/restart it -> `reset()`
- Need the current token -> `getArcToken()`
- Need to trigger an invisible/programmatic flow -> `execute()`

Do not invent methods such as `verify()`, `destroy()`, or `reload()` unless the current ARCaptcha documentation explicitly provides them.
