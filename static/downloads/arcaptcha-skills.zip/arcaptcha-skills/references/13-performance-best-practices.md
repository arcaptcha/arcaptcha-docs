# Performance Best Practices

This reference covers performance optimization strategies for ARCaptcha integrations to minimize impact on page load, rendering, and user experience.

## Script Loading Strategies

### Async and Defer Attributes

Always load the ARCaptcha script with `async defer` to prevent blocking page rendering:

```html
<!-- Recommended: Non-blocking load -->
<script src="https://nwidget.arcaptcha.ir/1/api.js" async defer></script>
```

**Why this matters:**

- `async`: Script downloads in parallel with page parsing
- `defer`: Script executes after DOM is ready
- Combined: Non-blocking load with guaranteed DOM availability

**Avoid blocking loads:**

```html
<!-- ❌ Bad: Blocks page rendering -->
<script src="https://nwidget.arcaptcha.ir/1/api.js"></script>
```

### Script Placement

**Option 1: In `<head>` with async defer (recommended)**

```html
<!DOCTYPE html>
<html>
  <head>
    <title>My App</title>
    <script src="https://nwidget.arcaptcha.ir/1/api.js" async defer></script>
  </head>
  <body>
    <!-- Page content -->
  </body>
</html>
```

Benefits:

- Script starts downloading early
- Non-blocking due to async/defer
- Available when DOM is ready

**Option 2: Before closing `</body>`**

```html
<!DOCTYPE html>
<html>
  <head>
    <title>My App</title>
  </head>
  <body>
    <!-- Page content -->

    <script src="https://nwidget.arcaptcha.ir/1/api.js" async defer></script>
  </body>
</html>
```

Benefits:

- Page content loads first
- Script loads after initial render
- Good for below-the-fold CAPTCHAs

**Choose based on CAPTCHA placement:**

- Above the fold → Head with async/defer
- Below the fold → Before closing body

### Preconnect for Faster Loading

Add DNS preconnect to resolve ARCaptcha domains early:

```html
<head>
  <!-- Preconnect to ARCaptcha domains -->
  <link rel="preconnect" href="https://nwidget.arcaptcha.ir" />
  <link rel="preconnect" href="https://api.arcaptcha.co" />

  <script src="https://nwidget.arcaptcha.ir/1/api.js" async defer></script>
</head>
```

**Performance gain:** Reduces DNS lookup time by 20-120ms.

### Resource Hints

Use resource hints for critical performance optimization:

```html
<head>
  <!-- DNS prefetch (fallback for older browsers) -->
  <link rel="dns-prefetch" href="https://nwidget.arcaptcha.ir" />
  <link rel="dns-prefetch" href="https://api.arcaptcha.co" />

  <!-- Preconnect (modern browsers) -->
  <link rel="preconnect" href="https://nwidget.arcaptcha.ir" crossorigin />
  <link rel="preconnect" href="https://api.arcaptcha.co" crossorigin />

  <!-- Optional: Prefetch the script (use cautiously) -->
  <link
    rel="prefetch"
    href="https://nwidget.arcaptcha.ir/1/api.js"
    as="script"
  />
</head>
```

## Lazy Loading

### Load CAPTCHA on Demand

For below-the-fold or conditional CAPTCHAs, load the script only when needed:

```javascript
let scriptLoaded = false;
let scriptLoading = false;

function loadArcaptchaScript() {
  return new Promise((resolve, reject) => {
    if (scriptLoaded) {
      resolve();
      return;
    }

    if (scriptLoading) {
      // Wait for existing load
      const checkInterval = setInterval(() => {
        if (scriptLoaded) {
          clearInterval(checkInterval);
          resolve();
        }
      }, 100);
      return;
    }

    scriptLoading = true;

    const script = document.createElement("script");
    script.src = "https://nwidget.arcaptcha.ir/1/api.js";
    script.async = true;
    script.defer = true;

    script.onload = () => {
      scriptLoaded = true;
      scriptLoading = false;
      resolve();
    };

    script.onerror = () => {
      scriptLoading = false;
      reject(new Error("Failed to load ARCaptcha script"));
    };

    document.head.appendChild(script);
  });
}

// Load when user scrolls to form
const formObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        loadArcaptchaScript().then(() => {
          console.log("ARCaptcha loaded");
          // Render widget
          arcaptcha.render("captcha-container", {
            site_key: "YOUR_SITE_KEY",
          });
        });

        formObserver.disconnect();
      }
    });
  },
  { rootMargin: "100px" },
); // Load 100px before entering viewport

formObserver.observe(document.getElementById("contact-form"));
```

### React Lazy Loading

```jsx
import { useEffect, useRef, useState } from "react";

function useLazyArcaptcha() {
  const [loaded, setLoaded] = useState(false);
  const [loading, setLoading] = useState(false);

  const load = () => {
    if (loaded || loading || window.arcaptcha) {
      if (window.arcaptcha) setLoaded(true);
      return Promise.resolve();
    }

    setLoading(true);

    return new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = "https://nwidget.arcaptcha.ir/1/api.js";
      script.async = true;

      script.onload = () => {
        setLoaded(true);
        setLoading(false);
        resolve();
      };

      script.onerror = () => {
        setLoading(false);
        reject(new Error("Failed to load ARCaptcha"));
      };

      document.head.appendChild(script);
    });
  };

  return { loaded, loading, load };
}

function LazyContactForm() {
  const { loaded, load } = useLazyArcaptcha();
  const captchaRef = useRef(null);
  const formRef = useRef(null);

  useEffect(() => {
    // Load when form is visible
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          load();
          observer.disconnect();
        }
      },
      { rootMargin: "100px" },
    );

    if (formRef.current) {
      observer.observe(formRef.current);
    }

    return () => observer.disconnect();
  }, [load]);

  useEffect(() => {
    if (loaded && window.arcaptcha && captchaRef.current) {
      window.arcaptcha.render(captchaRef.current, {
        site_key: process.env.REACT_APP_ARCAPTCHA_SITE_KEY,
      });
    }
  }, [loaded]);

  return (
    <form ref={formRef}>
      <input type="email" required />
      <div ref={captchaRef} />
      <button type="submit">Submit</button>
    </form>
  );
}
```

## Multiple Widgets Optimization

### Render Multiple Widgets Efficiently

When a page has multiple CAPTCHAs, render them programmatically to control timing:

```javascript
window.addEventListener("load", () => {
  if (!window.arcaptcha) return;

  // Batch render all widgets
  const widgets = [
    { id: "captcha-1", siteKey: "KEY_1" },
    { id: "captcha-2", siteKey: "KEY_2" },
    { id: "captcha-3", siteKey: "KEY_3" },
  ];

  widgets.forEach(({ id, siteKey }) => {
    const container = document.getElementById(id);
    if (container) {
      arcaptcha.render(id, {
        site_key: siteKey,
      });
    }
  });
});
```

### Lazy Render Multiple Widgets

Only render widgets when they become visible:

```javascript
const widgetConfigs = new Map([
  ["login-captcha", { siteKey: "KEY_1", widgetId: null }],
  ["signup-captcha", { siteKey: "KEY_2", widgetId: null }],
  ["contact-captcha", { siteKey: "KEY_3", widgetId: null }],
]);

const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const containerId = entry.target.id;
        const config = widgetConfigs.get(containerId);

        if (config && !config.widgetId && window.arcaptcha) {
          config.widgetId = arcaptcha.render(containerId, {
            site_key: config.siteKey,
          });

          observer.unobserve(entry.target);
        }
      }
    });
  },
  { rootMargin: "50px" },
);

// Observe all CAPTCHA containers
widgetConfigs.forEach((_, containerId) => {
  const container = document.getElementById(containerId);
  if (container) {
    observer.observe(container);
  }
});
```

### Performance Impact

**Memory usage per widget:** ~1-2 MB
**Network requests per widget:** 3-5 requests
**Initial render time:** 100-300ms per widget

**Recommendation:** Limit to 2-3 visible widgets per page for optimal performance.

## SPA Cleanup and Memory Management

### React Cleanup

Prevent memory leaks by properly cleaning up references:

```jsx
import { useEffect, useRef } from "react";

function CaptchaComponent() {
  const containerRef = useRef(null);
  const widgetIdRef = useRef(null);

  useEffect(() => {
    if (window.arcaptcha && containerRef.current) {
      widgetIdRef.current = window.arcaptcha.render(containerRef.current, {
        site_key: process.env.REACT_APP_ARCAPTCHA_SITE_KEY,
      });
    }

    return () => {
      // Clear widget reference on unmount
      if (widgetIdRef.current) {
        // ARCaptcha has no destroy method, but clear our reference
        widgetIdRef.current = null;
      }
    };
  }, []);

  return <div ref={containerRef} />;
}
```

### Vue Cleanup

```vue
<script>
export default {
  data() {
    return {
      widgetId: null,
    };
  },

  mounted() {
    if (window.arcaptcha && this.$refs.captcha) {
      this.widgetId = window.arcaptcha.render(this.$refs.captcha, {
        site_key: process.env.VUE_APP_ARCAPTCHA_SITE_KEY,
      });
    }
  },

  beforeUnmount() {
    // Clear reference to prevent memory leak
    this.widgetId = null;
  },
};
</script>
```

### Angular Cleanup

```typescript
import { Component, ElementRef, ViewChild, OnDestroy } from "@angular/core";

@Component({
  selector: "app-captcha",
  template: "<div #captchaContainer></div>",
})
export class CaptchaComponent implements OnDestroy {
  @ViewChild("captchaContainer") captchaContainer!: ElementRef;
  private widgetId: string | null = null;

  ngAfterViewInit() {
    if (window.arcaptcha && this.captchaContainer) {
      this.widgetId = window.arcaptcha.render(
        this.captchaContainer.nativeElement,
        { site_key: environment.arcaptchaSiteKey },
      );
    }
  }

  ngOnDestroy() {
    // Clear reference
    this.widgetId = null;
  }
}
```

## Caching Strategies

### Service Worker Caching

Cache the ARCaptcha script for offline-first applications:

```javascript
// service-worker.js
const CACHE_NAME = "arcaptcha-v1";
const ARCAPTCHA_SCRIPT = "https://nwidget.arcaptcha.ir/1/api.js";

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.add(ARCAPTCHA_SCRIPT);
    }),
  );
});

self.addEventListener("fetch", (event) => {
  if (event.request.url === ARCAPTCHA_SCRIPT) {
    event.respondWith(
      caches.match(event.request).then((response) => {
        // Return cached version or fetch from network
        return (
          response ||
          fetch(event.request).then((networkResponse) => {
            // Update cache with new version
            return caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, networkResponse.clone());
              return networkResponse;
            });
          })
        );
      }),
    );
  }
});
```

**Note:** ARCaptcha must connect to its API at runtime. Cache only the widget script, not API endpoints.

### HTTP Caching

The ARCaptcha script includes appropriate cache headers. Ensure your CDN or proxy respects them:

```nginx
# Nginx example - proxy ARCaptcha requests
location /arcaptcha/ {
    proxy_pass https://nwidget.arcaptcha.ir/;
    proxy_cache_valid 200 1h;
    proxy_cache_use_stale error timeout updating;
}
```

## Bundle Size Optimization

### Avoid Bundling ARCaptcha Script

Never bundle the ARCaptcha script in your webpack/Rollup/Vite build:

```javascript
// ✅ Good: Load from CDN
<script src="https://nwidget.arcaptcha.ir/1/api.js" async defer></script>

// ❌ Bad: Don't import/bundle
// import arcaptcha from 'arcaptcha-script'; // Don't do this
```

**Why:** ARCaptcha script should load from official CDN for:

- Security updates
- Performance optimizations
- Browser cache sharing across sites

### Tree Shaking Framework Libraries

When using framework libraries, ensure tree shaking:

```javascript
// ✅ Good: Named import
import { Arcaptcha } from "arcaptcha-react";

// ❌ Avoid: Default import of entire library
// import ArcaptchaLib from 'arcaptcha-react';
```

## Performance Monitoring

### Measure Load Time

Track ARCaptcha script load performance:

```javascript
const perfObserver = new PerformanceObserver((list) => {
  list.getEntries().forEach((entry) => {
    if (entry.name.includes("arcaptcha")) {
      console.log("ARCaptcha load time:", entry.duration, "ms");

      // Send to analytics
      if (window.gtag) {
        gtag("event", "timing_complete", {
          name: "arcaptcha_load",
          value: Math.round(entry.duration),
          event_category: "ARCaptcha",
        });
      }
    }
  });
});

perfObserver.observe({ entryTypes: ["resource"] });
```

### Monitor Widget Render Time

Track how long widgets take to render:

```javascript
function renderCaptchaWithTiming(containerId, params) {
  const startTime = performance.now();

  const widgetId = arcaptcha.render(containerId, {
    ...params,
    rendered_callback: () => {
      const renderTime = performance.now() - startTime;
      console.log("Widget render time:", renderTime, "ms");

      // Send to analytics
      if (window.gtag) {
        gtag("event", "timing_complete", {
          name: "arcaptcha_render",
          value: Math.round(renderTime),
          event_category: "ARCaptcha",
        });
      }

      // Call original callback if provided
      if (params.rendered_callback) {
        params.rendered_callback();
      }
    },
  });

  return widgetId;
}
```

## Mobile Performance

### Responsive Loading

Adjust loading strategy for mobile devices:

```javascript
function shouldLazyLoad() {
  // Lazy load on mobile/slow connections
  const isMobile = /Android|webOS|iPhone|iPad|iPod/i.test(navigator.userAgent);
  const isSlowConnection =
    navigator.connection &&
    (navigator.connection.effectiveType === "slow-2g" ||
      navigator.connection.effectiveType === "2g");

  return isMobile || isSlowConnection;
}

if (shouldLazyLoad()) {
  // Load on interaction or visibility
  document.getElementById("contact-form").addEventListener(
    "focus",
    () => {
      loadArcaptchaScript();
    },
    { once: true },
  );
} else {
  // Load immediately on desktop/fast connections
  loadArcaptchaScript();
}
```

### Reduce Network Requests

Use invisible mode on mobile to reduce UI overhead:

```javascript
const isMobile = /Android|webOS|iPhone|iPad|iPod/i.test(navigator.userAgent);

arcaptcha.render("captcha-container", {
  site_key: "YOUR_SITE_KEY",
  size: isMobile ? "invisible" : "normal",
});
```

## Performance Checklist

- [ ] ARCaptcha script loaded with `async defer`
- [ ] Preconnect to ARCaptcha domains
- [ ] Script placed appropriately (head or before </body>)
- [ ] Lazy loading for below-the-fold CAPTCHAs
- [ ] Multiple widgets render only when visible
- [ ] SPA components clean up widget references
- [ ] Script not bundled in application build
- [ ] Performance monitoring in place
- [ ] Mobile-specific optimizations applied
- [ ] Service worker caching (optional, for offline support)

## Performance Budget

**Target metrics:**

- Script load: < 500ms (3G connection)
- First widget render: < 300ms
- Total blocking time: < 50ms
- Cumulative Layout Shift (CLS): < 0.1

**Monitoring:** Use Lighthouse, WebPageTest, or real user monitoring (RUM) to track these metrics.
