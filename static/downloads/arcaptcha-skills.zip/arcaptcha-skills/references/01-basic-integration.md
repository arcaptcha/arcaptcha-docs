# Basic Integration

Use this reference for a conventional server-backed form with a visible ARCaptcha widget.

## Client-side setup

Load the ARCaptcha API script over HTTPS:

```html
<script src="https://nwidget.arcaptcha.ir/1/api.js" async defer></script>
```

Put the widget inside the form:

```html
<form action="/signup" method="POST">
  <input type="email" name="email" required />

  <input type="password" name="password" required />

  <div class="arcaptcha" data-site-key="YOUR_SITE_KEY"></div>

  <button type="submit">Sign up</button>
</form>
```

After the CAPTCHA is successfully solved, ARCaptcha adds a hidden form field named `arcaptcha-token`.

## Important: preserve the token during form submission

Before implementing the backend, inspect how the application submits the form.

### Native HTML form submission

If the form uses normal browser submission:

```html
<form action="/signup" method="POST"></form>
```

and the ARCaptcha widget is inside the form, the browser submits the `arcaptcha-token` field together with the other form fields.

The backend can read:

```text
arcaptcha-token
```

from the submitted form data.

### JavaScript, fetch, Axios, or AJAX submission

If the application intercepts the submit event and sends the request using JavaScript, the CAPTCHA token must be explicitly included in that request.

Do not assume that the hidden `arcaptcha-token` field will automatically be included in a manually constructed JSON request.

For example:

```javascript
const form = document.querySelector("#signup-form");

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const formData = new FormData(form);

  const token = formData.get("arcaptcha-token");

  const response = await fetch("/api/signup", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      email: formData.get("email"),
      password: formData.get("password"),
      "arcaptcha-token": token,
    }),
  });
});
```

Alternatively, when the application uses the ARCaptcha JavaScript API and has a widget ID:

```javascript
const token = arcaptcha.getArcToken(widgetID);
```

Include the returned token in the request sent to the backend.

### Verify the complete token flow

Before considering the integration complete, verify this entire path:

```text
ARCaptcha
    ↓
arcaptcha-token
    ↓
form / JavaScript submit handler
    ↓
HTTP request
    ↓
backend request body
    ↓
ARCaptcha verification API
    ↓
success: true
    ↓
protected action
```

The token must actually be present in the HTTP request received by the backend.

## Backend flow

The backend receives `arcaptcha-token` together with the form data.

Call:

```text
POST https://api.arcaptcha.co/arcaptcha/api/verify
```

with JSON containing:

```json
{
  "secret_key": "YOUR_SECRET_KEY",
  "challenge_id": "TOKEN_FROM_FORM",
  "site_key": "YOUR_SITE_KEY"
}
```

Only continue the protected action when the verification response contains:

```json
{
  "success": true
}
```

Never expose `secret_key` in client-side code.

## Backend field mapping

The name used by the frontend and backend must match.

If the frontend sends:

```json
{
  "email": "user@example.com",
  "arcaptcha-token": "TOKEN"
}
```

the backend must read the corresponding `arcaptcha-token` field.

Do not assume that a field named `captchaToken`, `token`, or another name contains the ARCaptcha token unless the frontend explicitly sends it using that name.

## Mobile WebView

If the widget is being loaded in a mobile WebView and the integration requires an explicit domain, ARCaptcha supports a `domain` query parameter on the API script:

```html
<script
  src="https://nwidget.arcaptcha.ir/1/api.js?domain=example.com"
  async
  defer
></script>
```

Use the actual domain expected by the integration; do not blindly copy `example.com`.
