# Troubleshooting

Use this reference when an ARCaptcha integration renders incorrectly, does not return a token, fails verification, or behaves unexpectedly.

## Widget does not render

Check:

1. The script is loaded from `https://nwidget.arcaptcha.ir/1/api.js`.
2. The page is using HTTPS in production.
3. The `.arcaptcha` container exists when the script tries to render it.
4. `data-site-key` is present and correct.
5. Browser console/network errors are inspected.
6. The domain is configured correctly for the site key.
7. In an SPA, rendering occurs after the component mounts.

## Token is missing

For a normal form:

- Confirm the CAPTCHA was successfully solved.
- Confirm the `.arcaptcha` element is inside the form when relying on automatic form token insertion.
- Check for `arcaptcha-token` in the submitted request.

For programmatic/invisible mode:

- Confirm `execute()` is called after normal validation.
- Confirm success callback/promise handling receives a token.
- Confirm the token is sent to the backend.

## Verification fails

Check all three values:

```text
secret_key
site_key
challenge_id
```

The `challenge_id` must be the token received from the browser. The site key must correspond to the secret/account being used.

Also check that the token has not already been used or become too old.

## Form submits twice

This commonly happens with invisible CAPTCHA when both the button's native submit and the CAPTCHA callback submit the form.

Use one controlled flow:

```text
click
  -> preventDefault
  -> validate form
  -> execute CAPTCHA
  -> success callback
  -> submit/send request once
```

## CAPTCHA works once but not again

After a failed or completed application request, the widget may need to be reset before another attempt:

```js
arcaptcha.reset(widgetId);
```

Use the explicit widget ID when multiple widgets exist.

## Client-side error callback

Use `data-error-callback` to inspect client errors:

```js
function onError({ code, message }) {
  console.error(code, message);
}
```

The current documentation groups errors into `1xx` create-phase and `2xx` answer-phase categories, plus unknown errors.

## Never fix security failures by trusting the client

If server-side verification fails, do not bypass CAPTCHA verification because the browser widget looked successful. Fail closed for the protected operation and provide a recoverable user experience.
