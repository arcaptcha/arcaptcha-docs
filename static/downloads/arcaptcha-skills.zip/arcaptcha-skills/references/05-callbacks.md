# Callbacks

Use callbacks when application logic must react to ARCaptcha lifecycle events.

## Successful response

`data-callback` receives the ARCaptcha token:

```html
<div
  class="arcaptcha"
  data-site-key="YOUR_SITE_KEY"
  data-callback="onCaptchaSuccess"
></div>

<script>
  function onCaptchaSuccess(token) {
    // Send token to your backend or continue the controlled submission flow.
  }
</script>
```

## Lifecycle callbacks

Supported callbacks include:

- `rendered_callback`
- `error_callback`
- `reset_callback`
- `expired_callback`
- `chlexpired_callback`
- `blocked_callback`
- `clicked_callback`
- `opened_callback`
- `closed_callback`

## Error callback

The documented error callback receives an object containing `code` and `message`:

```js
function onError({ code, message }) {
  console.error(code, message);
}
```

### Complete error code reference

ARCaptcha v5.0.0 error codes are grouped by phase:

**1xx - Create Phase Errors:**
- `101` - **CREATE_SERVER_ERROR**: Server error during challenge creation
- `102` - **CREATE_NETWORK_ERROR**: Network error during challenge creation

**2xx - Answer Phase Errors:**
- `201` - **ANSWER_SERVER_ERROR**: Server error during challenge verification
- `202` - **ANSWER_NETWORK_ERROR**: Network error during challenge verification
- `203` - **ANSWER_WRONG_ERROR**: User provided wrong answer

**4xx - Unknown Errors:**
- `401` - **UNKNOWN_ERROR**: Unclassified error occurred

### Error handling example

```js
function onError({ code, message }) {
  console.error(`ARCaptcha Error ${code}: ${message}`);
  
  // Handle based on error type
  if (code >= 100 && code < 200) {
    // Create phase error - challenge couldn't be created
    alert('Unable to load security check. Please refresh the page.');
  } else if (code >= 200 && code < 300) {
    // Answer phase error - challenge failed
    if (code === 203) {
      // Wrong answer - user can retry
      console.log('User provided wrong answer, can retry');
    } else {
      alert('Security check failed. Please try again.');
    }
  } else {
    // Unknown error
    alert('An unexpected error occurred. Please try again.');
  }
}
```

Do not hard-code handling for undocumented error codes. Treat unknown errors as failures and keep the application recoverable.

## Submission callbacks

If a callback manually submits a form:

1. Prevent the original browser submit when necessary.
2. Start CAPTCHA.
3. Submit only after a successful token is available.
4. Ensure the callback cannot submit twice.
5. Let the backend verify the token.

Avoid creating an infinite loop such as `callback -> form.submit() -> CAPTCHA callback -> ...`.
