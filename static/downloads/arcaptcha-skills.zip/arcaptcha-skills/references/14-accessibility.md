# Accessibility

This reference covers accessibility best practices for ARCaptcha integrations to ensure compliance with WCAG guidelines and usability for all users, including those using assistive technologies.

## Overview

ARCaptcha widgets should be accessible to users with:
- Visual impairments (screen readers, screen magnifiers)
- Motor impairments (keyboard-only navigation)
- Cognitive impairments (clear instructions, error messages)
- Hearing impairments (visual-only challenges)

**Important:** ARCaptcha's challenge accessibility is managed by the widget itself. This guide focuses on how to integrate the widget accessibly into your application.

## ARIA Labels and Roles

### Add Descriptive Labels

Provide context for screen reader users about the CAPTCHA's purpose:

```html
<form>
  <label for="email">Email Address</label>
  <input id="email" name="email" type="email" required />
  
  <label for="password">Password</label>
  <input id="password" name="password" type="password" required />
  
  <!-- CAPTCHA with ARIA label -->
  <div 
    class="arcaptcha" 
    data-site-key="YOUR_SITE_KEY"
    role="group"
    aria-label="Security verification"
    aria-describedby="captcha-help"
  ></div>
  
  <p id="captcha-help" class="sr-only">
    Complete the security check to verify you are not a robot.
  </p>
  
  <button type="submit">Sign In</button>
</form>
```

**CSS for screen reader only text:**
```css
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}
```

### Programmatic Rendering with ARIA

```javascript
function renderAccessibleCaptcha(containerId, siteKey) {
  const container = document.getElementById(containerId);
  
  // Add ARIA attributes
  container.setAttribute('role', 'group');
  container.setAttribute('aria-label', 'Security verification');
  container.setAttribute('aria-live', 'polite');
  container.setAttribute('aria-atomic', 'true');
  
  // Render widget
  const widgetId = arcaptcha.render(containerId, {
    site_key: siteKey,
    callback: onCaptchaSuccess,
    error_callback: onCaptchaError
  });
  
  return widgetId;
}

function onCaptchaSuccess(token) {
  // Announce success to screen readers
  announceToScreenReader('Security check completed successfully');
}

function onCaptchaError({ code, message }) {
  // Announce error to screen readers
  announceToScreenReader(`Security check failed: ${message}. Please try again.`);
}

function announceToScreenReader(message) {
  const announcement = document.getElementById('aria-announcements');
  if (announcement) {
    announcement.textContent = message;
  }
}
```

**Add announcement region to HTML:**
```html
<div 
  id="aria-announcements" 
  role="status" 
  aria-live="polite" 
  aria-atomic="true"
  class="sr-only"
></div>
```

## Keyboard Navigation

### Ensure Keyboard Accessibility

The ARCaptcha widget is keyboard-accessible by default. Ensure your form doesn't break this:

```html
<form onsubmit="handleSubmit(event)">
  <!-- All form elements must be keyboard accessible -->
  <input type="email" name="email" required />
  <input type="password" name="password" required />
  
  <!-- ARCaptcha is keyboard accessible by default -->
  <div class="arcaptcha" data-site-key="YOUR_SITE_KEY"></div>
  
  <!-- Submit button is keyboard accessible -->
  <button type="submit">Submit</button>
</form>
```

**Keyboard navigation flow:**
1. Tab to email field
2. Tab to password field
3. Tab to CAPTCHA widget (widget internally handles keyboard navigation)
4. Tab to submit button
5. Enter/Space to submit

### Skip Links for CAPTCHA

Provide skip links for keyboard users who have already completed the CAPTCHA:

```html
<a href="#after-captcha" class="skip-link">Skip to submit button</a>

<form>
  <input type="email" name="email" required />
  
  <div class="arcaptcha" data-site-key="YOUR_SITE_KEY"></div>
  
  <div id="after-captcha">
    <button type="submit">Submit</button>
  </div>
</form>
```

**CSS for skip links:**
```css
.skip-link {
  position: absolute;
  top: -40px;
  left: 0;
  background: #000;
  color: #fff;
  padding: 8px;
  z-index: 100;
}

.skip-link:focus {
  top: 0;
}
```

## Focus Management

### Maintain Focus Context

Ensure focus is managed correctly when CAPTCHA appears or resets:

```javascript
let widgetId;

function initCaptcha() {
  const container = document.getElementById('captcha-container');
  
  widgetId = arcaptcha.render('captcha-container', {
    site_key: 'YOUR_SITE_KEY',
    rendered_callback: () => {
      // Announce to screen readers
      announceToScreenReader('Security check loaded');
    },
    callback: onCaptchaSuccess,
    error_callback: onCaptchaError
  });
}

function onCaptchaError({ code, message }) {
  // Reset and refocus
  arcaptcha.reset(widgetId);
  
  // Announce error
  announceToScreenReader(`Security check failed: ${message}. Please try again.`);
  
  // Optional: Move focus to CAPTCHA for retry
  const container = document.getElementById('captcha-container');
  if (container) {
    container.focus();
  }
}

function onCaptchaSuccess(token) {
  // Announce success
  announceToScreenReader('Security check completed. You may now submit the form.');
  
  // Optional: Move focus to submit button
  const submitBtn = document.getElementById('submit-btn');
  if (submitBtn) {
    submitBtn.focus();
  }
}
```

### React Focus Management

```jsx
import { useEffect, useRef } from 'react';

function AccessibleCaptchaForm() {
  const captchaRef = useRef(null);
  const submitBtnRef = useRef(null);
  const announcementRef = useRef(null);

  const announce = (message) => {
    if (announcementRef.current) {
      announcementRef.current.textContent = message;
    }
  };

  useEffect(() => {
    if (window.arcaptcha && captchaRef.current) {
      window.arcaptcha.render(captchaRef.current, {
        site_key: process.env.REACT_APP_ARCAPTCHA_SITE_KEY,
        rendered_callback: () => {
          announce('Security check loaded');
        },
        callback: (token) => {
          announce('Security check completed');
          // Move focus to submit button
          submitBtnRef.current?.focus();
        },
        error_callback: ({ message }) => {
          announce(`Security check failed: ${message}. Please try again.`);
        }
      });
    }
  }, []);

  return (
    <form>
      <input type="email" required />
      
      <div
        ref={captchaRef}
        role="group"
        aria-label="Security verification"
      />
      
      <button ref={submitBtnRef} type="submit">
        Submit
      </button>
      
      <div
        ref={announcementRef}
        role="status"
        aria-live="polite"
        aria-atomic="true"
        className="sr-only"
      />
    </form>
  );
}
```

## Color Contrast and Visual Design

### Ensure Sufficient Contrast

The ARCaptcha widget's color can be customized. Ensure adequate contrast:

```html
<!-- Light theme (default) -->
<div 
  class="arcaptcha" 
  data-site-key="YOUR_SITE_KEY"
  data-theme="light"
></div>

<!-- Dark theme for dark mode sites -->
<div 
  class="arcaptcha" 
  data-site-key="YOUR_SITE_KEY"
  data-theme="dark"
></div>
```

### Respect User Preferences

Adapt theme based on user's system preferences:

```javascript
function renderResponsiveCaptcha() {
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  
  arcaptcha.render('captcha-container', {
    site_key: 'YOUR_SITE_KEY',
    theme: prefersDark ? 'dark' : 'light'
  });
}

// Listen for theme changes
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
  // Reset and re-render with new theme
  arcaptcha.reset();
  renderResponsiveCaptcha();
});
```

### Provide Visual Context

Add visible instructions near the CAPTCHA:

```html
<form>
  <label for="email">Email</label>
  <input id="email" type="email" required />
  
  <fieldset>
    <legend>Security Verification</legend>
    <p>Please complete the security check below to continue.</p>
    
    <div class="arcaptcha" data-site-key="YOUR_SITE_KEY"></div>
  </fieldset>
  
  <button type="submit">Submit</button>
</form>
```

## Error Messaging

### Accessible Error Handling

Provide clear, accessible error messages:

```javascript
function handleFormSubmit(event) {
  event.preventDefault();
  
  const token = arcaptcha.getArcToken();
  
  if (!token) {
    // Show accessible error
    showAccessibleError(
      'captcha-error',
      'Please complete the security check before submitting.'
    );
    
    // Move focus to CAPTCHA
    document.getElementById('captcha-container').focus();
    return;
  }
  
  // Continue with submission
  submitForm(token);
}

function showAccessibleError(errorId, message) {
  let errorElement = document.getElementById(errorId);
  
  if (!errorElement) {
    errorElement = document.createElement('div');
    errorElement.id = errorId;
    errorElement.className = 'error-message';
    errorElement.setAttribute('role', 'alert');
    errorElement.setAttribute('aria-live', 'assertive');
    
    const captchaContainer = document.getElementById('captcha-container');
    captchaContainer.parentNode.insertBefore(errorElement, captchaContainer);
  }
  
  errorElement.textContent = message;
}
```

**Accessible error styling:**
```css
.error-message {
  color: #d32f2f;
  background-color: #ffebee;
  border: 2px solid #d32f2f;
  padding: 12px;
  margin-bottom: 16px;
  border-radius: 4px;
  font-weight: 600;
}

/* Ensure sufficient contrast */
@media (prefers-color-scheme: dark) {
  .error-message {
    color: #ffcdd2;
    background-color: #b71c1c;
    border-color: #ffcdd2;
  }
}
```

### Validation Feedback

Provide clear validation states:

```html
<form>
  <div class="form-field">
    <label for="email">Email</label>
    <input 
      id="email" 
      name="email" 
      type="email" 
      required 
      aria-required="true"
      aria-invalid="false"
      aria-describedby="email-error"
    />
    <span id="email-error" role="alert" class="error-message" style="display: none;"></span>
  </div>
  
  <div class="form-field">
    <fieldset>
      <legend>Security Verification <span aria-label="required">*</span></legend>
      <div 
        id="captcha-container"
        class="arcaptcha" 
        data-site-key="YOUR_SITE_KEY"
        aria-required="true"
        aria-invalid="false"
        aria-describedby="captcha-error"
      ></div>
      <span id="captcha-error" role="alert" class="error-message" style="display: none;"></span>
    </fieldset>
  </div>
  
  <button type="submit">Submit</button>
</form>
```

## Language and Localization

### Support Multiple Languages

Set appropriate language for international users:

```javascript
function renderLocalizedCaptcha() {
  // Detect user's language
  const userLang = navigator.language || navigator.userLanguage;
  const lang = userLang.startsWith('fa') ? 'fa' : 'en';
  
  arcaptcha.render('captcha-container', {
    site_key: 'YOUR_SITE_KEY',
    lang: lang
  });
}
```

### Provide Translated Instructions

Match CAPTCHA language with page content:

```html
<!-- English page -->
<div lang="en">
  <p>Please complete the security check below.</p>
  <div class="arcaptcha" data-site-key="YOUR_SITE_KEY" data-lang="en"></div>
</div>

<!-- Persian page -->
<div lang="fa" dir="rtl">
  <p>لطفا بررسی امنیتی زیر را تکمیل کنید.</p>
  <div class="arcaptcha" data-site-key="YOUR_SITE_KEY" data-lang="fa"></div>
</div>
```

## Reduced Motion

### Respect Prefers-Reduced-Motion

Users with vestibular disorders may need reduced animation:

```javascript
// Check for reduced motion preference
const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

// While ARCaptcha doesn't expose animation controls,
// you can inform users if animations might occur
if (prefersReducedMotion) {
  const notice = document.createElement('p');
  notice.className = 'sr-only';
  notice.textContent = 'This security check may contain animations.';
  
  const captchaContainer = document.getElementById('captcha-container');
  captchaContainer.parentNode.insertBefore(notice, captchaContainer);
}
```

## Mobile Accessibility

### Touch Target Size

Ensure CAPTCHA is large enough for touch interaction:

```css
.arcaptcha {
  /* Ensure minimum touch target size */
  min-width: 304px;
  min-height: 78px;
}

@media (max-width: 768px) {
  .arcaptcha {
    /* Full width on mobile */
    width: 100%;
    max-width: 100%;
  }
}
```

### Viewport and Zoom

Don't disable zoom on mobile:

```html
<!-- ✅ Good: Allows zooming -->
<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<!-- ❌ Bad: Prevents zooming -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
```

## Testing Accessibility

### Screen Reader Testing

Test with popular screen readers:
- **Windows:** NVDA (free), JAWS
- **macOS:** VoiceOver (built-in)
- **Linux:** Orca
- **iOS:** VoiceOver (built-in)
- **Android:** TalkBack (built-in)

**Testing checklist:**
- [ ] CAPTCHA is announced with context
- [ ] Instructions are clear and read aloud
- [ ] Success/error states are announced
- [ ] Form can be completed using screen reader only
- [ ] Tab order is logical

### Keyboard Navigation Testing

Test without a mouse:
- [ ] All form fields are reachable via Tab
- [ ] CAPTCHA widget can be activated with keyboard
- [ ] Focus is visible at all times
- [ ] No keyboard traps
- [ ] Enter/Space keys work as expected

### Automated Testing

Use accessibility testing tools:

```javascript
// Example: axe-core integration
import { axe } from 'jest-axe';

test('form with CAPTCHA is accessible', async () => {
  const { container } = render(<FormWithCaptcha />);
  const results = await axe(container);
  
  expect(results).toHaveNoViolations();
});
```

**Tools:**
- axe DevTools browser extension
- WAVE Web Accessibility Evaluation Tool
- Lighthouse accessibility audit
- Pa11y automated testing

## WCAG Compliance

### WCAG 2.1 Level AA Requirements

ARCaptcha integration should meet:

**1.1.1 Non-text Content (A)**
- Provide text alternatives for CAPTCHA purpose
- Use ARIA labels to describe function

**1.3.1 Info and Relationships (A)**
- Use semantic HTML (labels, fieldsets)
- Ensure programmatic relationships

**1.4.3 Contrast (AA)**
- Ensure 4.5:1 contrast for text
- Verify theme colors meet contrast requirements

**2.1.1 Keyboard (A)**
- All functionality available via keyboard
- No keyboard traps

**2.4.3 Focus Order (A)**
- Logical, intuitive tab order
- Focus follows visual layout

**3.2.2 On Input (A)**
- No unexpected context changes
- Clear when actions will occur

**3.3.1 Error Identification (A)**
- Clearly identify errors
- Describe error in text

**3.3.2 Labels or Instructions (A)**
- Provide clear labels
- Include instructions when needed

**3.3.3 Error Suggestion (AA)**
- Suggest how to fix errors
- Provide recovery path

**4.1.2 Name, Role, Value (A)**
- Use ARIA where appropriate
- Ensure assistive tech compatibility

## Accessibility Checklist

- [ ] ARIA labels provide context about CAPTCHA purpose
- [ ] Screen reader announcements for success/error states
- [ ] Keyboard navigation works without mouse
- [ ] Focus management moves users through form logically
- [ ] Visible focus indicators on all interactive elements
- [ ] Color contrast meets WCAG AA standards (4.5:1)
- [ ] Theme adapts to user's dark mode preference
- [ ] Error messages are clear and actionable
- [ ] Instructions visible and available to screen readers
- [ ] Language matches page content language
- [ ] Touch targets are adequately sized (44x44px minimum)
- [ ] Viewport allows zooming on mobile
- [ ] Skip links available for keyboard users
- [ ] Tested with screen readers (VoiceOver, NVDA, JAWS)
- [ ] Automated accessibility tests pass

## Additional Resources

- [WCAG 2.1 Guidelines](https://www.w3.org/WAI/WCAG21/quickref/)
- [ARIA Authoring Practices Guide](https://www.w3.org/WAI/ARIA/apg/)
- [WebAIM Screen Reader Testing](https://webaim.org/articles/screenreader_testing/)
- [Deque axe DevTools](https://www.deque.com/axe/devtools/)

**Note:** While this guide covers integration accessibility, ARCaptcha's challenge accessibility (actual puzzle solving) is managed by the widget itself. Focus your testing on the integration points: form context, error handling, and navigation flow.
