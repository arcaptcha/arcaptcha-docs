# Configuration

ARCaptcha v5.0.0 configures widgets through `data-*` attributes or the equivalent parameters passed to `arcaptcha.render()`.

## Supported container attributes

| Attribute | Render parameter | Values / type | Purpose |
|---|---|---|---|
| `data-site-key` | `site_key` | public site key | Required site key |
| `data-size` | `size` | `normal`, `invisible` | Widget size |
| `data-theme` | `theme` | `light`, `dark` | Theme |
| `data-color` | `color` | color name or hex | Widget color |
| `data-error-print` | `error_print` | `0`, `1` | Error message display |
| `data-lang` | `lang` | e.g. `en`, `fa` | Widget language |
| `data-callback` | `callback` | function name | Called after successful response |
| `data-rendered-callback` | `rendered_callback` | function name | Called after rendering |
| `data-error-callback` | `error_callback` | function name | Called after error |
| `data-reset-callback` | `reset_callback` | function name | Called after reset |
| `data-expired-callback` | `expired_callback` | function name | Called after expiration |
| `data-chlexpired-callback` | `chlexpired_callback` | function name | Called after challenge expiration |
| `data-blocked-callback` | `blocked_callback` | function name | Called when blocked as bot |
| `data-clicked-callback` | `clicked_callback` | function name | Called after click/execute |
| `data-opened-callback` | `opened_callback` | function name | Called when challenge opens |
| `data-closed-callback` | `closed_callback` | function name | Called when challenge closes |

Use the spelling and values supported by the current ARCaptcha documentation. In particular, verify the `data-size` value against the installed widget version before changing it.

## Example

```html
<div
  class="arcaptcha"
  data-site-key="YOUR_SITE_KEY"
  data-theme="dark"
  data-lang="en"
  data-color="#000000"
  data-callback="onSubmit"
></div>
```

## Explicit render parameters

The same configuration can be supplied without the `data-` prefix:

```js
arcaptcha.render("captcha-1", {
  site_key: "YOUR_SITE_KEY",
  theme: "dark",
  lang: "en",
  size: "invisible"
});
```

## Test keys

The current ARCaptcha configuration documentation lists these test values:

```text
site-key:    0000000000
secret-key:  00000000000000000000
arcaptcha-token: 000000000000000000000000000000
```

They are for automated integration tests and do not provide anti-bot protection. Never use them as production credentials.
