# Testing Strategies

This reference covers strategies for testing ARCaptcha integrations in development, automated testing, and CI/CD environments.

## Test Keys

ARCaptcha provides test credentials that bypass bot protection for automated testing. **These keys provide NO security** and must ONLY be used in test environments.

### Test credentials

| Parameter | Test Value |
|-----------|-----------|
| `site_key` | `0000000000` |
| `secret_key` | `00000000000000000000` |
| `arcaptcha-token` | `000000000000000000000000000000` |

### Using test keys

**Frontend (development/test environment):**
```html
<div class="arcaptcha" data-site-key="0000000000"></div>
```

**Backend verification (test environment):**
```javascript
const result = await axios.post('https://api.arcaptcha.co/arcaptcha/api/verify', {
  challenge_id: '000000000000000000000000000000',
  site_key: '0000000000',
  secret_key: '00000000000000000000'
});

// result.data.success === true
```

### Environment-based key selection

Use environment variables to switch between test and production keys:

```javascript
const SITE_KEY = process.env.NODE_ENV === 'test'
  ? '0000000000'
  : process.env.ARCAPTCHA_SITE_KEY;

const SECRET_KEY = process.env.NODE_ENV === 'test'
  ? '00000000000000000000'
  : process.env.ARCAPTCHA_SECRET_KEY;
```

**⚠️ Critical security rule:** Never deploy test keys to production. Always verify environment-specific configuration before deployment.

## Unit Testing Strategies

### Mocking the ARCaptcha widget

For client-side unit tests, mock the global `arcaptcha` object:

**Jest example:**
```javascript
// __mocks__/arcaptcha.js
global.arcaptcha = {
  render: jest.fn((container, params) => {
    // Return mock widget ID
    return 'mock-widget-id';
  }),
  
  execute: jest.fn(() => {
    // Return promise with mock token
    return Promise.resolve({
      arcaptcha_token: 'mock-token-12345'
    });
  }),
  
  reset: jest.fn(),
  
  getArcToken: jest.fn(() => 'mock-token-12345')
};

// In your test file
describe('ARCaptcha Integration', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('renders widget with correct site key', () => {
    const container = document.createElement('div');
    container.id = 'captcha';
    
    arcaptcha.render('captcha', {
      site_key: 'test-site-key',
      callback: jest.fn()
    });
    
    expect(arcaptcha.render).toHaveBeenCalledWith('captcha', {
      site_key: 'test-site-key',
      callback: expect.any(Function)
    });
  });

  test('executes widget and returns token', async () => {
    const widgetId = 'mock-widget-id';
    const result = await arcaptcha.execute(widgetId);
    
    expect(result.arcaptcha_token).toBe('mock-token-12345');
  });
});
```

**React Testing Library example:**
```javascript
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import CaptchaForm from './CaptchaForm';

// Mock ARCaptcha
global.arcaptcha = {
  render: jest.fn(() => 'widget-1'),
  execute: jest.fn(() => Promise.resolve({ arcaptcha_token: 'mock-token' })),
  reset: jest.fn()
};

describe('CaptchaForm', () => {
  test('submits form with captcha token', async () => {
    const onSubmit = jest.fn();
    render(<CaptchaForm onSubmit={onSubmit} />);
    
    const submitButton = screen.getByRole('button', { name: /submit/i });
    await userEvent.click(submitButton);
    
    await waitFor(() => {
      expect(onSubmit).toHaveBeenCalledWith(
        expect.objectContaining({
          token: 'mock-token'
        })
      );
    });
  });
});
```

### Backend verification mocking

Mock the verification API for backend tests:

**Node.js with Jest:**
```javascript
jest.mock('axios');
const axios = require('axios');

describe('ARCaptcha Verification', () => {
  test('accepts valid token', async () => {
    axios.post.mockResolvedValue({
      data: { success: true }
    });
    
    const result = await verifyArcaptcha('test-token');
    
    expect(result).toBe(true);
    expect(axios.post).toHaveBeenCalledWith(
      'https://api.arcaptcha.co/arcaptcha/api/verify',
      expect.objectContaining({
        challenge_id: 'test-token'
      })
    );
  });

  test('rejects invalid token', async () => {
    axios.post.mockResolvedValue({
      data: {
        success: false,
        'error-codes': ['invalid-input-response']
      }
    });
    
    const result = await verifyArcaptcha('bad-token');
    
    expect(result).toBe(false);
  });

  test('handles network errors', async () => {
    axios.post.mockRejectedValue(new Error('Network error'));
    
    const result = await verifyArcaptcha('test-token');
    
    expect(result).toBe(false);
  });
});
```

**Python with unittest.mock:**
```python
import unittest
from unittest.mock import patch, Mock
from myapp import verify_arcaptcha

class TestArcaptchaVerification(unittest.TestCase):
    
    @patch('requests.post')
    def test_accepts_valid_token(self, mock_post):
        mock_response = Mock()
        mock_response.json.return_value = {'success': True}
        mock_post.return_value = mock_response
        
        result = verify_arcaptcha('test-token')
        
        self.assertTrue(result)
        mock_post.assert_called_once()
    
    @patch('requests.post')
    def test_rejects_invalid_token(self, mock_post):
        mock_response = Mock()
        mock_response.json.return_value = {
            'success': False,
            'error-codes': ['invalid-input-response']
        }
        mock_post.return_value = mock_response
        
        result = verify_arcaptcha('bad-token')
        
        self.assertFalse(result)
    
    @patch('requests.post')
    def test_handles_network_errors(self, mock_post):
        mock_post.side_effect = Exception('Network error')
        
        result = verify_arcaptcha('test-token')
        
        self.assertFalse(result)
```

## Integration Testing

### Using test keys in integration tests

For integration tests, use actual test keys with the real ARCaptcha API:

```javascript
// integration.test.js
describe('Signup Flow Integration', () => {
  const TEST_SITE_KEY = '0000000000';
  const TEST_SECRET_KEY = '00000000000000000000';
  const TEST_TOKEN = '000000000000000000000000000000';

  test('complete signup with ARCaptcha', async () => {
    // Frontend submits with test token
    const response = await fetch('/api/signup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'test@example.com',
        password: 'securepass123',
        'arcaptcha-token': TEST_TOKEN
      })
    });
    
    const result = await response.json();
    expect(result.success).toBe(true);
  });
});
```

### Browser automation with test keys

Configure your test environment to use test keys:

**Cypress example:**
```javascript
// cypress/e2e/signup.cy.js
describe('Signup with ARCaptcha', () => {
  beforeEach(() => {
    // Visit page with test site key
    cy.visit('/signup?test=true'); // test=true loads test keys
  });

  it('completes signup flow', () => {
    cy.get('input[name="email"]').type('test@example.com');
    cy.get('input[name="password"]').type('securepass123');
    
    // ARCaptcha with test keys auto-completes
    cy.get('button[type="submit"]').click();
    
    cy.url().should('include', '/welcome');
    cy.contains('Registration successful');
  });
});
```

**Playwright example:**
```javascript
// tests/signup.spec.js
import { test, expect } from '@playwright/test';

test('signup with ARCaptcha', async ({ page }) => {
  await page.goto('/signup?test=true');
  
  await page.fill('input[name="email"]', 'test@example.com');
  await page.fill('input[name="password"]', 'securepass123');
  
  // Test keys make widget auto-complete
  await page.click('button[type="submit"]');
  
  await expect(page).toHaveURL(/\/welcome/);
  await expect(page.locator('text=Registration successful')).toBeVisible();
});
```

**Selenium example:**
```python
from selenium import webdriver
from selenium.webdriver.common.by import By

def test_signup_with_arcaptcha():
    driver = webdriver.Chrome()
    driver.get('http://localhost:3000/signup?test=true')
    
    driver.find_element(By.NAME, 'email').send_keys('test@example.com')
    driver.find_element(By.NAME, 'password').send_keys('securepass123')
    
    # Test keys make widget auto-complete
    driver.find_element(By.CSS_SELECTOR, 'button[type="submit"]').click()
    
    assert 'welcome' in driver.current_url
    assert 'Registration successful' in driver.page_source
    
    driver.quit()
```

## End-to-End (E2E) Testing

### Skipping ARCaptcha in E2E tests

For comprehensive E2E tests, consider these approaches:

**Option 1: Test mode flag**
Add a test mode to your application that bypasses CAPTCHA verification:

```javascript
// Backend route
app.post('/signup', async (req, res) => {
  const token = req.body['arcaptcha-token'];
  
  // Skip verification in test mode
  if (process.env.NODE_ENV === 'test' && process.env.SKIP_CAPTCHA === 'true') {
    // Continue without verification
  } else {
    const verified = await verifyArcaptcha(token);
    if (!verified) {
      return res.status(400).json({ error: 'CAPTCHA failed' });
    }
  }
  
  // Protected business logic
});
```

**⚠️ Security:** Ensure `SKIP_CAPTCHA` is never true in production.

**Option 2: Dedicated test environment**
Set up a separate test environment with test keys configured:

```javascript
// config.js
module.exports = {
  arcaptcha: {
    siteKey: process.env.ARCAPTCHA_SITE_KEY || '0000000000',
    secretKey: process.env.ARCAPTCHA_SECRET_KEY || '00000000000000000000'
  }
};
```

**Option 3: Mock verification endpoint**
Use a service like Mock Service Worker (MSW) to intercept verification requests:

```javascript
// mocks/handlers.js
import { rest } from 'msw';

export const handlers = [
  rest.post('https://api.arcaptcha.co/arcaptcha/api/verify', (req, res, ctx) => {
    return res(
      ctx.json({ success: true })
    );
  })
];

// Setup in tests
import { setupServer } from 'msw/node';
const server = setupServer(...handlers);

beforeAll(() => server.listen());
afterEach(() => server.resetHandlers());
afterAll(() => server.close());
```

## CI/CD Integration

### GitHub Actions

```yaml
# .github/workflows/test.yml
name: Test

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    
    env:
      NODE_ENV: test
      ARCAPTCHA_SITE_KEY: "0000000000"
      ARCAPTCHA_SECRET_KEY: "00000000000000000000"
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Install dependencies
        run: npm ci
      
      - name: Run unit tests
        run: npm run test:unit
      
      - name: Run integration tests
        run: npm run test:integration
      
      - name: Run E2E tests
        run: npm run test:e2e
```

### GitLab CI

```yaml
# .gitlab-ci.yml
test:
  stage: test
  image: node:18
  
  variables:
    NODE_ENV: "test"
    ARCAPTCHA_SITE_KEY: "0000000000"
    ARCAPTCHA_SECRET_KEY: "00000000000000000000"
  
  script:
    - npm ci
    - npm run test:unit
    - npm run test:integration
    - npm run test:e2e
  
  only:
    - merge_requests
    - main
```

### Jenkins

```groovy
// Jenkinsfile
pipeline {
    agent any
    
    environment {
        NODE_ENV = 'test'
        ARCAPTCHA_SITE_KEY = '0000000000'
        ARCAPTCHA_SECRET_KEY = '00000000000000000000'
    }
    
    stages {
        stage('Install') {
            steps {
                sh 'npm ci'
            }
        }
        
        stage('Test') {
            parallel {
                stage('Unit Tests') {
                    steps {
                        sh 'npm run test:unit'
                    }
                }
                stage('Integration Tests') {
                    steps {
                        sh 'npm run test:integration'
                    }
                }
                stage('E2E Tests') {
                    steps {
                        sh 'npm run test:e2e'
                    }
                }
            }
        }
    }
}
```

### CircleCI

```yaml
# .circleci/config.yml
version: 2.1

jobs:
  test:
    docker:
      - image: cimg/node:18.0
    
    environment:
      NODE_ENV: test
      ARCAPTCHA_SITE_KEY: "0000000000"
      ARCAPTCHA_SECRET_KEY: "00000000000000000000"
    
    steps:
      - checkout
      - restore_cache:
          keys:
            - v1-dependencies-{{ checksum "package-lock.json" }}
      - run: npm ci
      - save_cache:
          paths:
            - node_modules
          key: v1-dependencies-{{ checksum "package-lock.json" }}
      - run: npm run test:unit
      - run: npm run test:integration
      - run: npm run test:e2e

workflows:
  test_and_deploy:
    jobs:
      - test
```

## Test Coverage Best Practices

### What to test

**Frontend tests:**
- Widget renders correctly with valid site key
- Widget calls callback on success
- Error callback fires on failure
- Reset functionality works
- Execute() returns promise with token
- Form submission includes token

**Backend tests:**
- Verification succeeds with valid token
- Verification fails with invalid token
- Missing token is rejected
- Network errors are handled gracefully
- Error codes are parsed correctly
- Secret key is never exposed in logs

**Integration tests:**
- Complete user flow from widget to verification
- Form validation with CAPTCHA
- Error recovery flows
- Multi-step form scenarios

### What NOT to test

- Internal ARCaptcha widget behavior (black box)
- ARCaptcha API uptime (not your responsibility)
- Challenge difficulty or type (ARCaptcha's domain)

### Coverage goals

Aim for:
- **Unit tests:** 80%+ coverage of your integration code
- **Integration tests:** Key user flows (signup, login, contact)
- **E2E tests:** Critical paths with CAPTCHA protection

## Testing Checklist

Before deploying:

- [ ] Unit tests pass with mocked ARCaptcha
- [ ] Integration tests pass with test keys
- [ ] E2E tests complete successfully
- [ ] Test keys are NOT in production environment
- [ ] Production keys are in secure environment variables
- [ ] CI/CD pipeline uses test keys
- [ ] Secret key is never logged or exposed
- [ ] Error handling is tested (network, invalid tokens)
- [ ] Token verification timeout is tested
- [ ] Duplicate token submission is tested

## Troubleshooting Test Issues

### Test keys not working

**Problem:** Verification fails even with test keys.

**Solutions:**
- Verify exact test key values (case-sensitive)
- Check Content-Type header is `application/json`
- Ensure test environment variable is set correctly
- Confirm you're hitting the production verify endpoint (not a mock)

### Flaky E2E tests

**Problem:** Tests pass sometimes, fail other times.

**Solutions:**
- Add explicit waits for widget rendering
- Use test keys to eliminate challenge variability
- Mock the verification endpoint for deterministic behavior
- Check for race conditions in form submission

### CI/CD tests failing

**Problem:** Tests pass locally but fail in CI.

**Solutions:**
- Verify environment variables are set in CI configuration
- Check network access to ARCaptcha API from CI environment
- Ensure test keys are properly escaped in YAML
- Review CI logs for actual error messages

## Security Reminder

**Never use test keys in production.** They provide zero bot protection and publicly advertise that your application's security is disabled. Always verify production environment configuration before deployment.
