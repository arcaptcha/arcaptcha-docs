# Invisible CAPTCHA

Use invisible mode when the user should not normally see a checkbox/widget and ARCaptcha should run in the background, presenting a challenge only when required.

## Choosing the implementation

Choose the simplest implementation that satisfies the user's request.

### Default: Option 1

If the user asks for an invisible CAPTCHA but does **not** explicitly request programmatic control, JavaScript API control, `execute()`, dynamic triggering, or custom CAPTCHA execution, use **Option 1: Automatically bind to a button**.

Do not introduce `arcaptcha.render()` or `arcaptcha.execute()` unnecessarily.

### Use Option 2 when requested

Use **Option 2: Invisible programmatic execution** when the user explicitly requests or the existing application requires:

- programmatic CAPTCHA execution
- `arcaptcha.execute()`
- JavaScript API control
- manual triggering
- dynamic CAPTCHA execution
- a widget ID
- calling CAPTCHA from custom JavaScript
- executing CAPTCHA as part of a custom submit flow
- dynamically created forms or buttons where automatic binding is not appropriate

If the application already uses a custom JavaScript/AJAX submission flow, prefer Option 2 when automatic button binding cannot cleanly integrate with that submission flow.

---

## Option 1: Automatically bind to a button

This is the **default invisible integration**.

Apply the `arcaptcha` class and site key to the submit button:

```html
<form id="my-form">
  <input id="email" name="email" type="email" required />

  <button
    type="submit"
    class="arcaptcha"
    data-site-key="YOUR_SITE_KEY"
    data-callback="onSubmit"
  >
    Submit
  </button>
</form>
```

When attached to a submit button, use a callback to control form submission.

Do not allow both the browser's default submit and the callback-driven submit to fire twice.

Example:

```js
function onSubmit(token) {
  document.getElementById("my-form").submit();
}
```

The callback receives the ARCaptcha token.

### Server-backed forms

The callback-driven submission must eventually send the token to the backend.

If the application uses native HTML form submission, keep the CAPTCHA integration inside the form so the token can be submitted with the form data.

The backend must verify the token before performing the protected action.

### JavaScript/AJAX forms

If the existing form uses `fetch()`, Axios, XMLHttpRequest, or another custom request mechanism, do not assume that automatic button binding will automatically place the token into a manually constructed JSON request.

In that situation, use Option 2 when necessary so the token can be explicitly obtained and included in the request.

---

## Option 2: Invisible programmatic execution

Use this option when the user explicitly requests programmatic control or when the application's submission architecture requires manual CAPTCHA execution.

Render a widget with `size: "invisible"`:

```html
<div
  id="captcha-1"
  class="arcaptcha"
  data-site-key="YOUR_SITE_KEY"
  data-size="invisible"
></div>
```

Render it programmatically:

```js
const widgetId = arcaptcha.render("captcha-1", {
  site_key: "YOUR_SITE_KEY",
  size: "invisible",
});
```

Execute it when the application decides the user is ready:

```js
function validateAndSubmit(event) {
  event.preventDefault();

  if (!document.getElementById("field").value) {
    return;
  }

  arcaptcha.execute(widgetId);
}
```

### Promise-based execution

When the application needs direct access to the token, use the promise returned by `execute()`:

```js
arcaptcha
  .execute(widgetId)
  .then(({ arcaptcha_token }) => {
    // Send the token to the backend.
  })
  .catch((error) => {
    // Keep the form usable and handle the failure.

    console.error(error);
  });
```

For a JavaScript/AJAX submission, include the token in the request:

```js
const { arcaptcha_token } = await arcaptcha.execute(widgetId);

await fetch("/api/signup", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    email,
    password,
    "arcaptcha-token": arcaptcha_token,
  }),
});
```

The backend must verify the token before performing the protected action.

---

## Important UX rule

Run normal client-side validation before starting an invisible CAPTCHA when possible.

Do not invoke CAPTCHA for a form that is already known to be invalid.

For programmatic integrations, the recommended flow is:

```text
User submits
    ↓
Client-side validation
    ↓
arcaptcha.execute(widgetId)
    ↓
Receive arcaptcha_token
    ↓
Send token with protected request
    ↓
Backend verification
    ↓
Protected action
```

Do not perform the protected action based only on successful client-side CAPTCHA execution.

---

## Implementation rule for agents

Do not automatically choose the more complex programmatic implementation just because it is available.

Prefer:

1. **Option 1** when the user simply asks for invisible CAPTCHA.
2. **Option 2** when the user explicitly asks for programmatic/manual/API-controlled execution or the existing application requires it.

When in doubt, use the simpler Option 1 unless the application's architecture makes it unsuitable.
