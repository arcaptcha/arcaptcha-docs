---
name: arcaptcha
version: 1.0.0
description: Integrate ARCaptcha v5.0.0 into web applications. Use when the user asks to add, configure, render, execute, reset, troubleshoot, test, or verify ARCaptcha, including standard widgets, invisible CAPTCHA, programmatic rendering, callbacks, widget methods, configuration, and React/Vue/Angular/Next.js integrations.
---

# ARCaptcha Integration Skill

Use this skill whenever ARCaptcha needs to be integrated or changed in an application.

## Source of truth

The ARCaptcha v5.0.0 documentation is available at:

- https://docs.arcaptcha.co/installation/
- https://docs.arcaptcha.co/configuration/
- https://docs.arcaptcha.co/invisible%20captcha/
- https://docs.arcaptcha.co/Widget%20methods/
- https://docs.arcaptcha.co/plugins/

Prefer the reference files in this skill for implementation guidance. If a feature is not covered here, consult the official documentation before inventing an API.

## Security requirements

- A site key is public and may appear in browser code.
- A secret key MUST remain server-side. Never put it in HTML, JavaScript bundles, React/Vue components, browser environment variables, or other client-delivered code.
- Client-side CAPTCHA success is not sufficient to authorize a protected operation.
- Send the ARCaptcha token/challenge ID to the backend and verify it server-side.
- Only execute the protected business operation when server-side verification returns `success: true`.
- Tokens are single-use and should be verified promptly.

## First: inspect the project

Before editing code:

1. Identify the framework/runtime (plain HTML, React, Vue, Next.js, server-rendered app, etc.).
2. Find the form/action that must be protected.
3. Determine whether the user wants a visible widget, invisible CAPTCHA, or programmatic rendering.
4. Locate the backend endpoint that handles the protected operation.
5. Follow existing project conventions for forms, API requests, validation, state management, and environment variables.
6. Do not introduce a new framework, dependency, or architecture unless necessary.

## Choose the integration

### Core Integration

- Simple form / normal visible widget -> `references/01-basic-integration.md`
- Dynamic rendering / SPA / widget lifecycle -> `references/02-programmatic-rendering.md`
- Hidden until a challenge is required -> `references/03-invisible-captcha.md`
- Size, theme, language, color, callbacks, or data attributes -> `references/04-configuration.md`
- Event/callback-driven submission -> `references/05-callbacks.md`
- Reset, token retrieval, execute, or widget IDs -> `references/06-widget-methods.md`
- Backend token verification -> `references/07-server-verification.md`
- React, Vue, Angular, or Next.js -> `references/08-framework-integration.md` and the matching example
- Unexpected behavior/errors -> `references/09-troubleshooting.md`

### Advanced Topics

- Official framework libraries (React, Vue, Angular, Flutter, backend SDKs) -> `references/10-framework-libraries.md`
- Testing strategies (unit, integration, E2E, CI/CD) -> `references/11-testing-strategies.md`
- Common patterns (multi-step forms, AJAX, SPA, error recovery) -> `references/12-common-patterns.md`
- Performance optimization (lazy loading, multiple widgets, caching) -> `references/13-performance-best-practices.md`
- Accessibility (ARIA, keyboard navigation, WCAG compliance) -> `references/14-accessibility.md`

### Examples

- HTML: `examples/html.md`
- React: `examples/react.md`
- Vue: `examples/vue.md`
- Next.js: `examples/nextjs.md`
- Angular: `examples/angular.md`
- Python backend: `examples/python-backend.md`
- PHP backend: `examples/php-backend.md`
- Go backend: `examples/go-backend.md`

## Standard architecture

For every protected action with a backend, implement the **complete end-to-end flow**:

1. Render or execute ARCaptcha in the browser.
2. Obtain the token:
   - Automatic form → `arcaptcha-token` form field
   - Programmatic rendering → `arcaptcha.getArcToken(widgetId)`
   - `execute()` → token returned by `arcaptcha.execute()`

3. Send the token to the application's backend as `arcaptcha-token`.
4. Backend MUST read `arcaptcha-token` and verify it server-side using:
   `POST https://api.arcaptcha.co/arcaptcha/api/verify`
   with `secret_key`, `site_key`, and `challenge_id: token`.
5. Continue the protected business logic **only when `success === true`**.

**The integration is incomplete if frontend CAPTCHA is implemented without actual backend verification. Do not leave verification as a comment, TODO, or `console.log()`.**

Never call the verification API from browser code because it would expose the secret key.

**Important:**

- The frontend sends a parameter named `arcaptcha-token` (with hyphen)
- The backend verification API expects `challenge_id` (underscore)
- Never call the verification API from browser code - that would expose the secret key

**Example flow:**

```javascript
// Frontend: Token automatically available as 'arcaptcha-token'
const formData = new FormData(form);
const token = formData.get("arcaptcha-token");

// Or with AJAX:
fetch("/api/submit", {
  method: "POST",
  body: JSON.stringify({
    email: email,
    "arcaptcha-token": token, // Send with hyphen
  }),
});

// Backend: Extract and verify
const token = req.body["arcaptcha-token"]; // Extract with hyphen

// Verify API call:
axios.post("https://api.arcaptcha.co/arcaptcha/api/verify", {
  challenge_id: token, // Send as challenge_id (underscore)
  site_key: SITE_KEY,
  secret_key: SECRET_KEY,
});
```

## Default integration preference

**Always prefer the simplest approach unless explicitly requested otherwise.**

### Default: Automatic Simple Widget

When the user asks to "add ARCaptcha" or "add CAPTCHA" without specifying a mode:

1. **Use automatic rendering** with a simple `.arcaptcha` div and `data-site-key`
2. **Do NOT use** invisible mode
3. **Do NOT use** programmatic rendering (`arcaptcha.render()`)
4. **Do NOT use** `arcaptcha.execute()`

This applies to all scenarios unless the user explicitly requests:

- "invisible CAPTCHA"
- "programmatic control"
- "execute on button click"
- Or the application architecture absolutely requires it (SPA with complex lifecycle)

### When to Use Invisible Mode

Only use invisible CAPTCHA (`data-size="invisible"`) when the user specifically asks for:

- "invisible CAPTCHA"
- "hidden CAPTCHA"
- "CAPTCHA that doesn't show unless needed"

When implementing invisible mode, use the invisible reference and explicitly handle the submission flow. Invisible mode requires a callback or `arcaptcha.execute()` depending on how it is triggered.

### When to Use Programmatic Rendering

Only use `arcaptcha.render()` when:

- The user explicitly requests programmatic control
- The application is a SPA that needs to render widgets dynamically
- Multiple widgets need individual lifecycle management
- The framework requires explicit rendering (complex React/Vue/Angular scenarios)

### Examples

**✅ User says:** "Add ARCaptcha to my contact form"
**→ Use:** Simple automatic widget (`<div class="arcaptcha" data-site-key="..."></div>`)

**✅ User says:** "Add invisible ARCaptcha to login"
**→ Use:** Invisible mode with explicit handling

**✅ User says:** "Add ARCaptcha with programmatic control"
**→ Use:** `arcaptcha.render()` with widget ID management

**❌ Don't assume:** Complex approaches when simple will work

## Implementation rules

- Use the public site key supplied by the user; never invent a production site key.
- Keep the ARCaptcha API script loaded over HTTPS: `https://widget.arcaptcha.ir/1/api.js`.
- For a standard widget, use a `.arcaptcha` container with `data-site-key`.
- For explicit rendering, use `arcaptcha.render(container, params)` and retain the returned widget ID when multiple widgets or lifecycle control are needed.
- Use `arcaptcha.reset(widgetID)` to reset a widget.
- Use `arcaptcha.getArcToken(widgetID)` when the application needs to retrieve the current challenge ID/token programmatically.
- Use `arcaptcha.execute(widgetID)` for programmatic execution, especially with invisible mode.
- Do not rely on undocumented methods or options.
- Preserve user input and existing validation behavior when integrating CAPTCHA.
- Avoid double submission when using callbacks or `execute()`.
- when `arcaptcha.render()` receives a string container, use a valid CSS selector such as `"#captcha-1"`, not `"captcha-1"`.

## Verification checklist

Before considering the task complete:

### Security & Configuration

- [ ] Correct site key is used
- [ ] Secret key is server-only (never in client code)
- [ ] Keys loaded from environment variables, not hardcoded
- [ ] Test keys not deployed to production

### Frontend Integration

- [ ] Widget script loaded with `async defer`
- [ ] Widget renders correctly
- [ ] Browser receives CAPTCHA token after successful completion
- [ ] Token is sent to the application's backend
- [ ] Error/expired/reset behavior does not leave form permanently blocked
- [ ] Existing form validation and UX still work
- [ ] Widget accessible via keyboard navigation

### Backend Verification

- [ ] Backend sends `secret_key`, `site_key`, and `challenge_id` to ARCaptcha verification
- [ ] Backend checks `success === true` before protected action
- [ ] Verification errors handled gracefully
- [ ] Network timeouts handled appropriately
- [ ] Token verification occurs before business logic

### Testing & Quality

- [ ] Integration tested with test keys
- [ ] Error scenarios tested (invalid token, network failure)
- [ ] No console errors or warnings
- [ ] Performance impact acceptable (< 500ms script load)
- [ ] Accessibility requirements met (ARIA labels, keyboard access)

## Testing

ARCaptcha provides test credentials for automated integration testing. They do not provide anti-bot protection and must only be used in test environments.

**Test credentials:**

- Site key: `0000000000`
- Secret key: `00000000000000000000`
- Test token: `000000000000000000000000000000`

For comprehensive testing strategies, see `references/11-testing-strategies.md`.

## Quick reference selector

**By framework:**

- React app → `references/08-framework-integration.md` + `examples/react.md`
- Vue 2/3 app → `references/08-framework-integration.md` + `examples/vue.md`
- Angular app → `references/08-framework-integration.md` + `examples/angular.md`
- Next.js app → `references/08-framework-integration.md` + `examples/nextjs.md`
- Plain HTML → `references/01-basic-integration.md` + `examples/html.md`

**By backend:**

- Python (Flask/Django/FastAPI) → `examples/python-backend.md`
- PHP → `examples/php-backend.md`
- Go → `examples/go-backend.md`
- Node.js → `references/07-server-verification.md`

**By use case:**

- Official library packages → `references/10-framework-libraries.md`
- Multi-step form → `references/12-common-patterns.md`
- AJAX submission → `references/12-common-patterns.md`
- Testing/CI/CD → `references/11-testing-strategies.md`
- Performance optimization → `references/13-performance-best-practices.md`
- Accessibility/WCAG → `references/14-accessibility.md`
- Invisible mode → `references/03-invisible-captcha.md`
- Multiple widgets → `references/13-performance-best-practices.md`

## Final response to the user

After implementation, briefly state:

1. What files/components were changed
2. Which ARCaptcha mode was used (normal/invisible) and why
3. Where the site key is configured
4. Where server-side verification occurs
5. Any environment variables or setup steps still required
6. Whether accessibility requirements were addressed

**Important:** Do not claim the integration is secure merely because the widget renders. Always confirm that server-side verification is implemented and working.
