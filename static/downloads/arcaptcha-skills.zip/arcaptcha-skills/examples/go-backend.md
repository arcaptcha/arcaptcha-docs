# ARCaptcha Go Backend Example

Backend token verification examples for Go applications.

## Standard net/http Example

```go
package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"time"
)

const arcaptchaVerifyURL = "https://api.arcaptcha.co/arcaptcha/api/verify"

// VerifyRequest represents the request payload for ARCaptcha verification
type VerifyRequest struct {
	ChallengeID string `json:"challenge_id"`
	SiteKey     string `json:"site_key"`
	SecretKey   string `json:"secret_key"`
}

// VerifyResponse represents the response from ARCaptcha verification
type VerifyResponse struct {
	Success    bool     `json:"success"`
	ErrorCodes []string `json:"error-codes,omitempty"`
}

// ContactRequest represents the contact form payload
type ContactRequest struct {
	Name           string `json:"name"`
	Email          string `json:"email"`
	Message        string `json:"message"`
	ArcaptchaToken string `json:"arcaptcha-token"`
}

// Response represents a standard API response
type Response struct {
	Success bool   `json:"success"`
	Message string `json:"message,omitempty"`
	Error   string `json:"error,omitempty"`
}

// VerifyArcaptcha verifies the ARCaptcha token with ARCaptcha API
func VerifyArcaptcha(token string) (bool, error) {
	if token == "" {
		return false, fmt.Errorf("CAPTCHA token is missing")
	}

	payload := VerifyRequest{
		ChallengeID: token,
		SiteKey:     os.Getenv("ARCAPTCHA_SITE_KEY"),
		SecretKey:   os.Getenv("ARCAPTCHA_SECRET_KEY"),
	}

	jsonData, err := json.Marshal(payload)
	if err != nil {
		return false, fmt.Errorf("failed to marshal request: %w", err)
	}

	client := &http.Client{
		Timeout: 10 * time.Second,
	}

	req, err := http.NewRequest("POST", arcaptchaVerifyURL, bytes.NewBuffer(jsonData))
	if err != nil {
		return false, fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		return false, fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return false, fmt.Errorf("failed to read response: %w", err)
	}

	var result VerifyResponse
	if err := json.Unmarshal(body, &result); err != nil {
		return false, fmt.Errorf("failed to parse response: %w", err)
	}

	if !result.Success {
		log.Printf("ARCaptcha verification failed: %v", result.ErrorCodes)
		return false, fmt.Errorf("verification failed: %v", result.ErrorCodes)
	}

	return true, nil
}

// ContactHandler handles contact form submissions
func ContactHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")

	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		json.NewEncoder(w).Encode(Response{
			Success: false,
			Error:   "Method not allowed",
		})
		return
	}

	var req ContactRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(Response{
			Success: false,
			Error:   "Invalid JSON",
		})
		return
	}

	// Verify CAPTCHA
	verified, err := VerifyArcaptcha(req.ArcaptchaToken)
	if err != nil || !verified {
		w.WriteHeader(http.StatusBadRequest)
		errorMsg := "CAPTCHA verification failed"
		if err != nil {
			errorMsg = err.Error()
		}
		json.NewEncoder(w).Encode(Response{
			Success: false,
			Error:   errorMsg,
		})
		return
	}

	// Validate input
	if req.Name == "" || req.Email == "" || req.Message == "" {
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(Response{
			Success: false,
			Error:   "All fields are required",
		})
		return
	}

	// Process contact form
	// ... your business logic here ...

	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(Response{
		Success: true,
		Message: "Message sent successfully",
	})
}

// SignupHandler handles user signup
func SignupHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")

	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		json.NewEncoder(w).Encode(Response{
			Success: false,
			Error:   "Method not allowed",
		})
		return
	}

	var req struct {
		Email          string `json:"email"`
		Password       string `json:"password"`
		ArcaptchaToken string `json:"arcaptcha-token"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(Response{
			Success: false,
			Error:   "Invalid JSON",
		})
		return
	}

	// Verify CAPTCHA
	verified, err := VerifyArcaptcha(req.ArcaptchaToken)
	if err != nil || !verified {
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(Response{
			Success: false,
			Error:   "CAPTCHA verification failed",
		})
		return
	}

	// Validate and create user
	// ... your business logic here ...

	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(Response{
		Success: true,
		Message: "Account created successfully",
	})
}

func main() {
	http.HandleFunc("/api/contact", ContactHandler)
	http.HandleFunc("/api/signup", SignupHandler)

	log.Println("Server starting on :8080")
	if err := http.ListenAndServe(":8080", nil); err != nil {
		log.Fatal(err)
	}
}
```

## Middleware Example

```go
package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"time"
)

// ArcaptchaMiddleware is a middleware that verifies ARCaptcha tokens
func ArcaptchaMiddleware(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")

		// Read body
		body, err := io.ReadAll(r.Body)
		if err != nil {
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(map[string]interface{}{
				"error": "Failed to read request body",
			})
			return
		}

		// Restore body for next handler
		r.Body = io.NopCloser(bytes.NewBuffer(body))

		// Parse request to get token
		var data map[string]interface{}
		if err := json.Unmarshal(body, &data); err != nil {
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(map[string]interface{}{
				"error": "Invalid JSON",
			})
			return
		}

		token, ok := data["arcaptcha-token"].(string)
		if !ok || token == "" {
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(map[string]interface{}{
				"error": "CAPTCHA token is missing",
			})
			return
		}

		// Verify token
		verified, err := VerifyArcaptcha(token)
		if err != nil || !verified {
			w.WriteHeader(http.StatusBadRequest)
			errorMsg := "CAPTCHA verification failed"
			if err != nil {
				errorMsg = err.Error()
			}
			json.NewEncoder(w).Encode(map[string]interface{}{
				"error": errorMsg,
			})
			return
		}

		// Restore body again and call next handler
		r.Body = io.NopCloser(bytes.NewBuffer(body))
		next(w, r)
	}
}

// ProtectedHandler is an example handler protected by ARCaptcha
func ProtectedHandler(w http.ResponseWriter, r *http.Request) {
	// CAPTCHA already verified by middleware
	var req ContactRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(Response{
			Success: false,
			Error:   "Invalid request",
		})
		return
	}

	// Process request
	// ... your business logic here ...

	json.NewEncoder(w).Encode(Response{
		Success: true,
		Message: "Success",
	})
}

func main() {
	// Apply middleware to specific routes
	http.HandleFunc("/api/contact", ArcaptchaMiddleware(ProtectedHandler))
	http.HandleFunc("/api/signup", ArcaptchaMiddleware(ProtectedHandler))

	log.Println("Server starting on :8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}
```

## Gin Framework Example

```go
package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"time"

	"github.com/gin-gonic/gin"
)

type ArcaptchaVerifier struct {
	siteKey   string
	secretKey string
	verifyURL string
	client    *http.Client
}

func NewArcaptchaVerifier() *ArcaptchaVerifier {
	return &ArcaptchaVerifier{
		siteKey:   os.Getenv("ARCAPTCHA_SITE_KEY"),
		secretKey: os.Getenv("ARCAPTCHA_SECRET_KEY"),
		verifyURL: "https://api.arcaptcha.co/arcaptcha/api/verify",
		client: &http.Client{
			Timeout: 10 * time.Second,
		},
	}
}

func (v *ArcaptchaVerifier) Verify(token string) (bool, error) {
	if token == "" {
		return false, fmt.Errorf("CAPTCHA token is missing")
	}

	payload := map[string]string{
		"challenge_id": token,
		"site_key":     v.siteKey,
		"secret_key":   v.secretKey,
	}

	jsonData, err := json.Marshal(payload)
	if err != nil {
		return false, err
	}

	req, err := http.NewRequest("POST", v.verifyURL, bytes.NewBuffer(jsonData))
	if err != nil {
		return false, err
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := v.client.Do(req)
	if err != nil {
		return false, err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return false, err
	}

	var result struct {
		Success    bool     `json:"success"`
		ErrorCodes []string `json:"error-codes"`
	}

	if err := json.Unmarshal(body, &result); err != nil {
		return false, err
	}

	return result.Success, nil
}

// Gin middleware
func ArcaptchaMiddleware(verifier *ArcaptchaVerifier) gin.HandlerFunc {
	return func(c *gin.Context) {
		var data map[string]interface{}
		if err := c.ShouldBindJSON(&data); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid JSON"})
			c.Abort()
			return
		}

		token, ok := data["arcaptcha-token"].(string)
		if !ok || token == "" {
			c.JSON(http.StatusBadRequest, gin.H{"error": "CAPTCHA token is missing"})
			c.Abort()
			return
		}

		verified, err := verifier.Verify(token)
		if err != nil || !verified {
			errorMsg := "CAPTCHA verification failed"
			if err != nil {
				errorMsg = err.Error()
			}
			c.JSON(http.StatusBadRequest, gin.H{"error": errorMsg})
			c.Abort()
			return
		}

		// Store data in context for handler
		c.Set("requestData", data)
		c.Next()
	}
}

func main() {
	r := gin.Default()
	verifier := NewArcaptchaVerifier()

	// Apply middleware to routes
	r.POST("/api/contact", ArcaptchaMiddleware(verifier), func(c *gin.Context) {
		data, _ := c.Get("requestData")
		requestData := data.(map[string]interface{})

		// Process request
		// ... your business logic here ...

		c.JSON(http.StatusOK, gin.H{
			"success": true,
			"message": "Message sent successfully",
		})
	})

	r.POST("/api/signup", ArcaptchaMiddleware(verifier), func(c *gin.Context) {
		data, _ := c.Get("requestData")
		requestData := data.(map[string]interface{})

		// Create user
		// ... your business logic here ...

		c.JSON(http.StatusCreated, gin.H{
			"success": true,
			"message": "Account created successfully",
		})
	})

	r.Run(":8080")
}
```

## Environment Variables

```bash
# .env
export ARCAPTCHA_SITE_KEY=your_site_key_here
export ARCAPTCHA_SECRET_KEY=your_secret_key_here
```

## go.mod

```
module myapp

go 1.21

require (
	github.com/gin-gonic/gin v1.9.1
)
```

## Notes

- Use `http.Client` with timeout for verification requests
- Store keys in environment variables
- Handle network errors gracefully (timeout, connection errors)
- Log verification failures for monitoring
- Validate all user input in addition to CAPTCHA
- Use middleware for reusable CAPTCHA verification
- Return appropriate HTTP status codes
- Consider using `context.Context` for cancellation and timeouts
- Use HTTPS in production
- Implement rate limiting to prevent abuse
