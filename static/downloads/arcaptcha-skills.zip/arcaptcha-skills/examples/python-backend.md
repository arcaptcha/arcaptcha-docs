# ARCaptcha Python Backend Example

Backend token verification examples for Python applications.

## Flask Example

```python
from flask import Flask, request, jsonify
import requests
import os
from functools import wraps

app = Flask(__name__)

# Load from environment variables
ARCAPTCHA_SITE_KEY = os.getenv('ARCAPTCHA_SITE_KEY')
ARCAPTCHA_SECRET_KEY = os.getenv('ARCAPTCHA_SECRET_KEY')
ARCAPTCHA_VERIFY_URL = 'https://api.arcaptcha.co/arcaptcha/api/verify'


def verify_arcaptcha(token):
    """
    Verify ARCaptcha token with ARCaptcha API.
    
    Args:
        token (str): The arcaptcha-token from the client
    
    Returns:
        tuple: (success: bool, error_message: str or None)
    """
    if not token:
        return False, 'CAPTCHA token is missing'
    
    try:
        response = requests.post(
            ARCAPTCHA_VERIFY_URL,
            json={
                'challenge_id': token,
                'site_key': ARCAPTCHA_SITE_KEY,
                'secret_key': ARCAPTCHA_SECRET_KEY
            },
            headers={'Content-Type': 'application/json'},
            timeout=10
        )
        
        result = response.json()
        
        if result.get('success'):
            return True, None
        else:
            error_codes = result.get('error-codes', [])
            return False, f'CAPTCHA verification failed: {", ".join(error_codes)}'
            
    except requests.exceptions.Timeout:
        return False, 'CAPTCHA verification timeout'
    except requests.exceptions.RequestException as e:
        app.logger.error(f'ARCaptcha verification error: {e}')
        return False, 'CAPTCHA verification service unavailable'
    except Exception as e:
        app.logger.error(f'Unexpected error during CAPTCHA verification: {e}')
        return False, 'CAPTCHA verification failed'


def require_captcha(f):
    """
    Decorator to require ARCaptcha verification for routes.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = request.json.get('arcaptcha-token') if request.is_json else request.form.get('arcaptcha-token')
        
        success, error = verify_arcaptcha(token)
        
        if not success:
            return jsonify({'error': error}), 400
        
        return f(*args, **kwargs)
    
    return decorated_function


@app.route('/api/contact', methods=['POST'])
@require_captcha
def contact():
    """
    Contact form endpoint with ARCaptcha protection.
    """
    data = request.json if request.is_json else request.form
    
    name = data.get('name')
    email = data.get('email')
    message = data.get('message')
    
    # Validate input
    if not all([name, email, message]):
        return jsonify({'error': 'All fields are required'}), 400
    
    # Process contact form (send email, save to database, etc.)
    # ... your business logic here ...
    
    return jsonify({'success': True, 'message': 'Message sent successfully'}), 200


@app.route('/api/signup', methods=['POST'])
def signup():
    """
    Signup endpoint with manual ARCaptcha verification.
    """
    data = request.json
    
    # Verify CAPTCHA
    token = data.get('arcaptcha-token')
    success, error = verify_arcaptcha(token)
    
    if not success:
        return jsonify({'error': error}), 400
    
    # Extract user data
    email = data.get('email')
    password = data.get('password')
    
    # Validate input
    if not email or not password:
        return jsonify({'error': 'Email and password are required'}), 400
    
    # Create user account
    # ... your user creation logic here ...
    
    return jsonify({'success': True, 'message': 'Account created successfully'}), 201


@app.route('/api/login', methods=['POST'])
@require_captcha
def login():
    """
    Login endpoint with ARCaptcha protection.
    """
    data = request.json
    
    email = data.get('email')
    password = data.get('password')
    
    # Authenticate user
    # ... your authentication logic here ...
    
    return jsonify({'success': True, 'token': 'your_jwt_token_here'}), 200


if __name__ == '__main__':
    app.run(debug=True)
```

## Django Example

```python
# views.py
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.conf import settings
import requests
import json
import logging

logger = logging.getLogger(__name__)

ARCAPTCHA_VERIFY_URL = 'https://api.arcaptcha.co/arcaptcha/api/verify'


def verify_arcaptcha(token):
    """
    Verify ARCaptcha token.
    
    Args:
        token (str): The arcaptcha-token from the client
    
    Returns:
        tuple: (success: bool, error_message: str or None)
    """
    if not token:
        return False, 'CAPTCHA token is missing'
    
    try:
        response = requests.post(
            ARCAPTCHA_VERIFY_URL,
            json={
                'challenge_id': token,
                'site_key': settings.ARCAPTCHA_SITE_KEY,
                'secret_key': settings.ARCAPTCHA_SECRET_KEY
            },
            headers={'Content-Type': 'application/json'},
            timeout=10
        )
        
        result = response.json()
        
        if result.get('success'):
            return True, None
        else:
            error_codes = result.get('error-codes', [])
            logger.warning(f'ARCaptcha verification failed: {error_codes}')
            return False, 'CAPTCHA verification failed'
            
    except requests.exceptions.Timeout:
        logger.error('ARCaptcha verification timeout')
        return False, 'CAPTCHA verification timeout'
    except requests.exceptions.RequestException as e:
        logger.error(f'ARCaptcha verification error: {e}')
        return False, 'CAPTCHA verification service unavailable'
    except Exception as e:
        logger.error(f'Unexpected error: {e}')
        return False, 'CAPTCHA verification failed'


@csrf_exempt
@require_http_methods(["POST"])
def contact_view(request):
    """
    Contact form view with ARCaptcha protection.
    """
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON'}, status=400)
    
    # Verify CAPTCHA
    token = data.get('arcaptcha-token')
    success, error = verify_arcaptcha(token)
    
    if not success:
        return JsonResponse({'error': error}, status=400)
    
    # Extract form data
    name = data.get('name')
    email = data.get('email')
    message = data.get('message')
    
    # Validate input
    if not all([name, email, message]):
        return JsonResponse({'error': 'All fields are required'}, status=400)
    
    # Process contact form
    # ... your business logic here ...
    
    return JsonResponse({'success': True, 'message': 'Message sent successfully'})


@csrf_exempt
@require_http_methods(["POST"])
def signup_view(request):
    """
    Signup view with ARCaptcha protection.
    """
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON'}, status=400)
    
    # Verify CAPTCHA
    token = data.get('arcaptcha-token')
    success, error = verify_arcaptcha(token)
    
    if not success:
        return JsonResponse({'error': error}, status=400)
    
    # Extract user data
    email = data.get('email')
    password = data.get('password')
    
    # Validate and create user
    # ... your user creation logic here ...
    
    return JsonResponse({'success': True, 'message': 'Account created'}, status=201)


# urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('api/contact', views.contact_view, name='contact'),
    path('api/signup', views.signup_view, name='signup'),
]


# settings.py
import os

ARCAPTCHA_SITE_KEY = os.getenv('ARCAPTCHA_SITE_KEY')
ARCAPTCHA_SECRET_KEY = os.getenv('ARCAPTCHA_SECRET_KEY')
```

## FastAPI Example

```python
from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel, EmailStr
import requests
import os
from typing import Optional
import logging

app = FastAPI()
logger = logging.getLogger(__name__)

# Configuration
ARCAPTCHA_SITE_KEY = os.getenv('ARCAPTCHA_SITE_KEY')
ARCAPTCHA_SECRET_KEY = os.getenv('ARCAPTCHA_SECRET_KEY')
ARCAPTCHA_VERIFY_URL = 'https://api.arcaptcha.co/arcaptcha/api/verify'


# Pydantic models
class ContactRequest(BaseModel):
    name: str
    email: EmailStr
    message: str
    arcaptcha_token: str = None
    
    class Config:
        # Allow both Python and JSON naming conventions
        fields = {
            'arcaptcha_token': 'arcaptcha-token'
        }


class SignupRequest(BaseModel):
    email: EmailStr
    password: str
    arcaptcha_token: str = None
    
    class Config:
        fields = {
            'arcaptcha_token': 'arcaptcha-token'
        }


class Response(BaseModel):
    success: bool
    message: str


def verify_arcaptcha(token: Optional[str]) -> bool:
    """
    Verify ARCaptcha token.
    
    Args:
        token: The arcaptcha-token from the client
    
    Returns:
        bool: True if verification succeeded
    
    Raises:
        HTTPException: If verification fails
    """
    if not token:
        raise HTTPException(status_code=400, detail='CAPTCHA token is missing')
    
    try:
        response = requests.post(
            ARCAPTCHA_VERIFY_URL,
            json={
                'challenge_id': token,
                'site_key': ARCAPTCHA_SITE_KEY,
                'secret_key': ARCAPTCHA_SECRET_KEY
            },
            headers={'Content-Type': 'application/json'},
            timeout=10
        )
        
        result = response.json()
        
        if not result.get('success'):
            error_codes = result.get('error-codes', [])
            logger.warning(f'ARCaptcha verification failed: {error_codes}')
            raise HTTPException(
                status_code=400,
                detail=f'CAPTCHA verification failed: {", ".join(error_codes)}'
            )
        
        return True
        
    except requests.exceptions.Timeout:
        logger.error('ARCaptcha verification timeout')
        raise HTTPException(status_code=504, detail='CAPTCHA verification timeout')
    except requests.exceptions.RequestException as e:
        logger.error(f'ARCaptcha verification error: {e}')
        raise HTTPException(
            status_code=503,
            detail='CAPTCHA verification service unavailable'
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f'Unexpected error: {e}')
        raise HTTPException(status_code=500, detail='CAPTCHA verification failed')


@app.post('/api/contact', response_model=Response)
async def contact(request: ContactRequest):
    """
    Contact form endpoint with ARCaptcha protection.
    """
    # Verify CAPTCHA
    verify_arcaptcha(request.arcaptcha_token)
    
    # Process contact form
    # ... your business logic here ...
    
    return Response(success=True, message='Message sent successfully')


@app.post('/api/signup', response_model=Response, status_code=201)
async def signup(request: SignupRequest):
    """
    Signup endpoint with ARCaptcha protection.
    """
    # Verify CAPTCHA
    verify_arcaptcha(request.arcaptcha_token)
    
    # Create user account
    # ... your user creation logic here ...
    
    return Response(success=True, message='Account created successfully')


# Dependency injection example
async def verify_captcha_dependency(arcaptcha_token: Optional[str] = None):
    """
    FastAPI dependency for CAPTCHA verification.
    """
    verify_arcaptcha(arcaptcha_token)


@app.post('/api/protected')
async def protected_endpoint(verified: None = Depends(verify_captcha_dependency)):
    """
    Example of using CAPTCHA verification as a dependency.
    """
    return {'message': 'This endpoint is protected by ARCaptcha'}


if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=8000)
```

## Environment Variables

```bash
# .env
ARCAPTCHA_SITE_KEY=your_site_key_here
ARCAPTCHA_SECRET_KEY=your_secret_key_here
```

## Requirements

```txt
# requirements.txt
Flask==3.0.0
requests==2.31.0

# Or for Django
Django==5.0.0
requests==2.31.0

# Or for FastAPI
fastapi==0.109.0
uvicorn==0.27.0
requests==2.31.0
pydantic[email]==2.5.0
```

## Notes

- Always verify tokens server-side before protected operations
- Store keys in environment variables, never in code
- Handle network errors gracefully (timeout, connection errors)
- Log verification failures for monitoring
- Tokens are single-use and short-lived
- Use HTTPS in production
- Consider rate limiting verification requests
