# ARCaptcha Angular Example

For Angular applications, render ARCaptcha in components using lifecycle hooks.

## Component with Explicit Rendering

```typescript
import {
  Component,
  ElementRef,
  ViewChild,
  AfterViewInit,
  OnDestroy,
} from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { environment } from "../environments/environment";

declare global {
  interface Window {
    arcaptcha: {
      render(container: HTMLElement | string, params: any): string;
      reset(widgetId?: string): void;
      execute(widgetId?: string): Promise<{ arcaptcha_token: string }>;
      getArcToken(widgetId?: string): string | null;
    };
  }
}

@Component({
  selector: "app-contact-form",
  template: `
    <form (ngSubmit)="onSubmit()" #contactForm="ngForm">
      <div class="form-group">
        <label for="name">Name</label>
        <input
          id="name"
          name="name"
          type="text"
          class="form-control"
          [(ngModel)]="formData.name"
          required
        />
      </div>

      <div class="form-group">
        <label for="email">Email</label>
        <input
          id="email"
          name="email"
          type="email"
          class="form-control"
          [(ngModel)]="formData.email"
          required
        />
      </div>

      <div class="form-group">
        <label for="message">Message</label>
        <textarea
          id="message"
          name="message"
          class="form-control"
          [(ngModel)]="formData.message"
          rows="4"
          required
        ></textarea>
      </div>

      <div #captchaContainer class="captcha-container"></div>

      <div *ngIf="errorMessage" class="alert alert-danger" role="alert">
        {{ errorMessage }}
      </div>

      <div *ngIf="successMessage" class="alert alert-success" role="alert">
        {{ successMessage }}
      </div>

      <button
        type="submit"
        class="btn btn-primary"
        [disabled]="!contactForm.valid || isSubmitting"
      >
        {{ isSubmitting ? "Sending..." : "Send Message" }}
      </button>
    </form>
  `,
  styles: [
    `
      .captcha-container {
        margin: 20px 0;
      }

      .form-group {
        margin-bottom: 15px;
      }

      .alert {
        margin-top: 15px;
      }
    `,
  ],
})
export class ContactFormComponent implements AfterViewInit, OnDestroy {
  @ViewChild("captchaContainer", { static: false })
  captchaContainer!: ElementRef;

  formData = {
    name: "",
    email: "",
    message: "",
  };

  widgetId: string | null = null;
  isSubmitting = false;
  errorMessage: string | null = null;
  successMessage: string | null = null;

  constructor(private http: HttpClient) {}

  ngAfterViewInit(): void {
    // Render ARCaptcha after view initializes
    if (window.arcaptcha && this.captchaContainer) {
      this.widgetId = window.arcaptcha.render(
        this.captchaContainer.nativeElement,
        {
          site_key: environment.arcaptchaSiteKey,
          theme: "light",
          lang: "en",
        },
      );
    }
  }

  ngOnDestroy(): void {
    // Clear widget reference
    this.widgetId = null;
  }

  onSubmit(): void {
    this.errorMessage = null;
    this.successMessage = null;

    // Get ARCaptcha token
    const token = this.widgetId
      ? window.arcaptcha.getArcToken(this.widgetId)
      : null;

    if (!token) {
      this.errorMessage = "Please complete the security check";
      return;
    }

    this.isSubmitting = true;

    // Submit form
    this.http
      .post("/api/contact", {
        ...this.formData,
        "arcaptcha-token": token,
      })
      .subscribe({
        next: () => {
          this.successMessage = "Message sent successfully!";
          this.resetForm();
        },
        error: (error) => {
          this.errorMessage = error.error?.message || "Failed to send message";
          this.resetCaptcha();
          this.isSubmitting = false;
        },
        complete: () => {
          this.isSubmitting = false;
        },
      });
  }

  resetForm(): void {
    this.formData = {
      name: "",
      email: "",
      message: "",
    };
    this.resetCaptcha();
  }

  resetCaptcha(): void {
    if (this.widgetId) {
      window.arcaptcha.reset(this.widgetId);
    }
  }
}
```

## Environment Configuration

```typescript
// src/environments/environment.ts
export const environment = {
  production: false,
  arcaptchaSiteKey: "YOUR_SITE_KEY",
};

// src/environments/environment.prod.ts
export const environment = {
  production: true,
  arcaptchaSiteKey: "YOUR_PRODUCTION_SITE_KEY",
};
```

## Module Setup

```typescript
// src/app/app.module.ts
import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";

import { AppComponent } from "./app.component";
import { ContactFormComponent } from "./contact-form/contact-form.component";

@NgModule({
  declarations: [AppComponent, ContactFormComponent],
  imports: [BrowserModule, FormsModule, HttpClientModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
```

## Load Script in index.html

```html
<!-- src/index.html -->
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>My Angular App</title>
    <base href="/" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="icon" type="image/x-icon" href="favicon.ico" />

    <!-- Load ARCaptcha script -->
    <script src="https://nwidget.arcaptcha.ir/1/api.js" async defer></script>
  </head>
  <body>
    <app-root></app-root>
  </body>
</html>
```

## Invisible CAPTCHA Example

```typescript
@Component({
  selector: "app-invisible-form",
  template: `
    <form (ngSubmit)="onSubmit()">
      <input
        type="email"
        [(ngModel)]="email"
        name="email"
        placeholder="Email"
        required
      />

      <div #captchaContainer></div>

      <button type="submit" [disabled]="isSubmitting">
        {{ isSubmitting ? "Processing..." : "Subscribe" }}
      </button>
    </form>
  `,
})
export class InvisibleFormComponent implements AfterViewInit {
  @ViewChild("captchaContainer") captchaContainer!: ElementRef;

  email = "";
  widgetId: string | null = null;
  isSubmitting = false;

  constructor(private http: HttpClient) {}

  ngAfterViewInit(): void {
    if (window.arcaptcha && this.captchaContainer) {
      this.widgetId = window.arcaptcha.render(
        this.captchaContainer.nativeElement,
        {
          site_key: environment.arcaptchaSiteKey,
          size: "invisible",
        },
      );
    }
  }

  async onSubmit(): Promise<void> {
    if (!this.email || !this.widgetId) {
      return;
    }

    this.isSubmitting = true;

    try {
      // Execute invisible CAPTCHA
      const { arcaptcha_token } = await window.arcaptcha.execute(this.widgetId);

      // Submit with token
      await this.http
        .post("/api/subscribe", {
          email: this.email,
          "arcaptcha-token": arcaptcha_token,
        })
        .toPromise();

      alert("Subscribed successfully!");
      this.email = "";
    } catch (error) {
      console.error("Subscription failed:", error);
      alert("Subscription failed. Please try again.");

      if (this.widgetId) {
        window.arcaptcha.reset(this.widgetId);
      }
    } finally {
      this.isSubmitting = false;
    }
  }
}
```

## Reactive Forms Example

```typescript
import { Component, ElementRef, ViewChild, AfterViewInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { HttpClient } from "@angular/common/http";

@Component({
  selector: "app-reactive-form",
  template: `
    <form [formGroup]="contactForm" (ngSubmit)="onSubmit()">
      <div class="form-group">
        <label for="name">Name</label>
        <input
          id="name"
          formControlName="name"
          type="text"
          class="form-control"
        />
        <div
          *ngIf="
            contactForm.get('name')?.invalid && contactForm.get('name')?.touched
          "
          class="text-danger"
        >
          Name is required
        </div>
      </div>

      <div class="form-group">
        <label for="email">Email</label>
        <input
          id="email"
          formControlName="email"
          type="email"
          class="form-control"
        />
        <div
          *ngIf="
            contactForm.get('email')?.invalid &&
            contactForm.get('email')?.touched
          "
          class="text-danger"
        >
          Valid email is required
        </div>
      </div>

      <div #captchaContainer></div>

      <button
        type="submit"
        class="btn btn-primary"
        [disabled]="contactForm.invalid || isSubmitting"
      >
        Submit
      </button>
    </form>
  `,
})
export class ReactiveFormComponent implements AfterViewInit {
  @ViewChild("captchaContainer") captchaContainer!: ElementRef;

  contactForm: FormGroup;
  widgetId: string | null = null;
  isSubmitting = false;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
  ) {
    this.contactForm = this.fb.group({
      name: ["", Validators.required],
      email: ["", [Validators.required, Validators.email]],
    });
  }

  ngAfterViewInit(): void {
    if (window.arcaptcha && this.captchaContainer) {
      this.widgetId = window.arcaptcha.render(
        this.captchaContainer.nativeElement,
        {
          site_key: environment.arcaptchaSiteKey,
        },
      );
    }
  }

  onSubmit(): void {
    if (this.contactForm.invalid) {
      return;
    }

    const token = this.widgetId
      ? window.arcaptcha.getArcToken(this.widgetId)
      : null;

    if (!token) {
      alert("Please complete the security check");
      return;
    }

    this.isSubmitting = true;

    this.http
      .post("/api/contact", {
        ...this.contactForm.value,
        "arcaptcha-token": token,
      })
      .subscribe({
        next: () => {
          alert("Form submitted successfully!");
          this.contactForm.reset();
          if (this.widgetId) {
            window.arcaptcha.reset(this.widgetId);
          }
        },
        error: () => {
          alert("Submission failed");
          if (this.widgetId) {
            window.arcaptcha.reset(this.widgetId);
          }
        },
        complete: () => {
          this.isSubmitting = false;
        },
      });
  }
}
```

## Notes

- Load the ARCaptcha script in `index.html` with `async defer`
- Use `AfterViewInit` lifecycle hook to ensure DOM element exists before rendering
- Store widget ID in component property for programmatic control
- Clean up widget references in `OnDestroy` to prevent memory leaks
- Use TypeScript declarations for type safety with `window.arcaptcha`
- Backend verification must be implemented separately (see backend examples)
