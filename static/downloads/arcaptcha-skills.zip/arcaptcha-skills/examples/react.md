# ARCaptcha React Example

For React, load the ARCaptcha script once and render after the container mounts.

```jsx
import { useEffect, useRef } from "react";

export default function Captcha({ siteKey, onToken }) {
  const containerRef = useRef(null);

  useEffect(() => {
    if (!window.arcaptcha || !containerRef.current) return;

    window.arcaptcha.render(containerRef.current, {
      site_key: siteKey,
      callback: onToken,
    });
  }, [siteKey, onToken]);

  return <div ref={containerRef} />;
}
```

For production applications, ensure the callback contract matches the ARCaptcha widget version in use and prevent duplicate renders when component state changes.
