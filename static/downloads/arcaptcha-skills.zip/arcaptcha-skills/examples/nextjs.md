# ARCaptcha Next.js Example

ARCaptcha browser code must run on the client.

```jsx
"use client";

import { useEffect, useRef } from "react";

export default function Captcha({ siteKey }) {
  const containerRef = useRef(null);

  useEffect(() => {
    if (!window.arcaptcha || !containerRef.current) return;

    window.arcaptcha.render(containerRef.current, {
      site_key: siteKey
    });
  }, [siteKey]);

  return <div ref={containerRef} />;
}
```

Load `https://widget.arcaptcha.ir/1/api.js` with the application's preferred Next.js script mechanism. Keep the secret key in a server-only environment variable and verify tokens from a server route/action before the protected operation.
