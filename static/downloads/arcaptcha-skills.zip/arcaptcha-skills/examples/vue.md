# ARCaptcha Vue Example

```vue
<script setup>
import { onMounted, ref } from "vue";

const captcha = ref(null);

onMounted(() => {
  if (!window.arcaptcha || !captcha.value) return;

  window.arcaptcha.render(captcha.value, {
    site_key: import.meta.env.VITE_ARCAPTCHA_SITE_KEY
  });
});
</script>

<template>
  <form @submit.prevent="submit">
    <input v-model="email" type="email" required />
    <div ref="captcha"></div>
    <button type="submit">Submit</button>
  </form>
</template>
```

Load the ARCaptcha API script once in the application shell. Never expose the secret key in `VITE_*` or other client-side environment variables.
