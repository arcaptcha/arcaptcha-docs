# ARCaptcha PHP Backend Example

Backend token verification examples for PHP applications.

## Procedural PHP Example

```php
<?php
// config.php
define('ARCAPTCHA_SITE_KEY', getenv('ARCAPTCHA_SITE_KEY'));
define('ARCAPTCHA_SECRET_KEY', getenv('ARCAPTCHA_SECRET_KEY'));
define('ARCAPTCHA_VERIFY_URL', 'https://api.arcaptcha.co/arcaptcha/api/verify');


// arcaptcha.php
function verifyArcaptcha($token) {
    if (empty($token)) {
        return [
            'success' => false,
            'error' => 'CAPTCHA token is missing'
        ];
    }
    
    $data = json_encode([
        'challenge_id' => $token,
        'site_key' => ARCAPTCHA_SITE_KEY,
        'secret_key' => ARCAPTCHA_SECRET_KEY
    ]);
    
    $options = [
        'http' => [
            'header'  => "Content-Type: application/json\r\n",
            'method'  => 'POST',
            'content' => $data,
            'timeout' => 10
        ]
    ];
    
    $context = stream_context_create($options);
    $result = @file_get_contents(ARCAPTCHA_VERIFY_URL, false, $context);
    
    if ($result === false) {
        error_log('ARCaptcha verification request failed');
        return [
            'success' => false,
            'error' => 'CAPTCHA verification service unavailable'
        ];
    }
    
    $response = json_decode($result, true);
    
    if (!isset($response['success'])) {
        error_log('ARCaptcha verification response invalid');
        return [
            'success' => false,
            'error' => 'CAPTCHA verification failed'
        ];
    }
    
    if (!$response['success']) {
        $errorCodes = isset($response['error-codes']) ? $response['error-codes'] : [];
        error_log('ARCaptcha verification failed: ' . implode(', ', $errorCodes));
        return [
            'success' => false,
            'error' => 'CAPTCHA verification failed',
            'codes' => $errorCodes
        ];
    }
    
    return [
        'success' => true
    ];
}


// contact.php
<?php
require_once 'config.php';
require_once 'arcaptcha.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if ($input === null) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON']);
    exit;
}

// Verify CAPTCHA
$token = $input['arcaptcha-token'] ?? null;
$verificationResult = verifyArcaptcha($token);

if (!$verificationResult['success']) {
    http_response_code(400);
    echo json_encode(['error' => $verificationResult['error']]);
    exit;
}

// Validate input
$name = $input['name'] ?? '';
$email = $input['email'] ?? '';
$message = $input['message'] ?? '';

if (empty($name) || empty($email) || empty($message)) {
    http_response_code(400);
    echo json_encode(['error' => 'All fields are required']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid email address']);
    exit;
}

// Process contact form (send email, save to database, etc.)
// ... your business logic here ...

http_response_code(200);
echo json_encode([
    'success' => true,
    'message' => 'Message sent successfully'
]);
?>


// signup.php
<?php
require_once 'config.php';
require_once 'arcaptcha.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

// Verify CAPTCHA
$token = $input['arcaptcha-token'] ?? null;
$verificationResult = verifyArcaptcha($token);

if (!$verificationResult['success']) {
    http_response_code(400);
    echo json_encode(['error' => $verificationResult['error']]);
    exit;
}

// Extract and validate user data
$email = filter_var($input['email'] ?? '', FILTER_VALIDATE_EMAIL);
$password = $input['password'] ?? '';

if (!$email) {
    http_response_code(400);
    echo json_encode(['error' => 'Valid email is required']);
    exit;
}

if (strlen($password) < 8) {
    http_response_code(400);
    echo json_encode(['error' => 'Password must be at least 8 characters']);
    exit;
}

// Create user account
// ... your user creation logic here ...

http_response_code(201);
echo json_encode([
    'success' => true,
    'message' => 'Account created successfully'
]);
?>
```

## Object-Oriented PHP Example

```php
<?php
// src/Arcaptcha/Verifier.php
namespace Arcaptcha;

class Verifier {
    private $siteKey;
    private $secretKey;
    private $verifyUrl = 'https://api.arcaptcha.co/arcaptcha/api/verify';
    
    public function __construct($siteKey, $secretKey) {
        $this->siteKey = $siteKey;
        $this->secretKey = $secretKey;
    }
    
    public function verify($token) {
        if (empty($token)) {
            throw new \InvalidArgumentException('CAPTCHA token is missing');
        }
        
        $data = json_encode([
            'challenge_id' => $token,
            'site_key' => $this->siteKey,
            'secret_key' => $this->secretKey
        ]);
        
        $ch = curl_init($this->verifyUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Content-Length: ' . strlen($data)
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        
        $result = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);
        
        if ($result === false) {
            error_log('ARCaptcha cURL error: ' . $curlError);
            throw new \RuntimeException('CAPTCHA verification service unavailable');
        }
        
        $response = json_decode($result, true);
        
        if ($httpCode !== 200 || !isset($response['success'])) {
            error_log('ARCaptcha verification failed with HTTP ' . $httpCode);
            throw new \RuntimeException('CAPTCHA verification failed');
        }
        
        if (!$response['success']) {
            $errorCodes = $response['error-codes'] ?? [];
            error_log('ARCaptcha verification failed: ' . implode(', ', $errorCodes));
            throw new VerificationException(
                'CAPTCHA verification failed',
                $errorCodes
            );
        }
        
        return true;
    }
}

class VerificationException extends \Exception {
    private $errorCodes;
    
    public function __construct($message, array $errorCodes = []) {
        parent::__construct($message);
        $this->errorCodes = $errorCodes;
    }
    
    public function getErrorCodes() {
        return $this->errorCodes;
    }
}


// src/Controllers/ContactController.php
namespace Controllers;

use Arcaptcha\Verifier;
use Arcaptcha\VerificationException;

class ContactController {
    private $verifier;
    
    public function __construct(Verifier $verifier) {
        $this->verifier = $verifier;
    }
    
    public function handle() {
        header('Content-Type: application/json');
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendError(405, 'Method not allowed');
            return;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if ($input === null) {
            $this->sendError(400, 'Invalid JSON');
            return;
        }
        
        try {
            // Verify CAPTCHA
            $token = $input['arcaptcha-token'] ?? null;
            $this->verifier->verify($token);
            
            // Validate input
            $this->validateContactForm($input);
            
            // Process form
            $this->processContact($input);
            
            $this->sendSuccess('Message sent successfully');
            
        } catch (VerificationException $e) {
            $this->sendError(400, 'CAPTCHA verification failed');
        } catch (\InvalidArgumentException $e) {
            $this->sendError(400, $e->getMessage());
        } catch (\RuntimeException $e) {
            $this->sendError(503, $e->getMessage());
        } catch (\Exception $e) {
            error_log('Contact form error: ' . $e->getMessage());
            $this->sendError(500, 'Internal server error');
        }
    }
    
    private function validateContactForm($input) {
        if (empty($input['name'])) {
            throw new \InvalidArgumentException('Name is required');
        }
        
        if (empty($input['email']) || !filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
            throw new \InvalidArgumentException('Valid email is required');
        }
        
        if (empty($input['message'])) {
            throw new \InvalidArgumentException('Message is required');
        }
    }
    
    private function processContact($input) {
        // Send email, save to database, etc.
        // ... your business logic here ...
    }
    
    private function sendError($code, $message) {
        http_response_code($code);
        echo json_encode(['error' => $message]);
    }
    
    private function sendSuccess($message, $code = 200) {
        http_response_code($code);
        echo json_encode([
            'success' => true,
            'message' => $message
        ]);
    }
}


// public/contact.php
<?php
require_once __DIR__ . '/../vendor/autoload.php';

use Arcaptcha\Verifier;
use Controllers\ContactController;

$verifier = new Verifier(
    getenv('ARCAPTCHA_SITE_KEY'),
    getenv('ARCAPTCHA_SECRET_KEY')
);

$controller = new ContactController($verifier);
$controller->handle();
?>
```

## Laravel Example

```php
<?php
// app/Services/ArcaptchaService.php
namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class ArcaptchaService
{
    private $siteKey;
    private $secretKey;
    private $verifyUrl = 'https://api.arcaptcha.co/arcaptcha/api/verify';
    
    public function __construct()
    {
        $this->siteKey = config('services.arcaptcha.site_key');
        $this->secretKey = config('services.arcaptcha.secret_key');
    }
    
    public function verify(string $token): bool
    {
        if (empty($token)) {
            return false;
        }
        
        try {
            $response = Http::timeout(10)->post($this->verifyUrl, [
                'challenge_id' => $token,
                'site_key' => $this->siteKey,
                'secret_key' => $this->secretKey
            ]);
            
            $result = $response->json();
            
            if (!isset($result['success'])) {
                Log::warning('ARCaptcha verification response invalid');
                return false;
            }
            
            if (!$result['success']) {
                $errorCodes = $result['error-codes'] ?? [];
                Log::warning('ARCaptcha verification failed', ['codes' => $errorCodes]);
                return false;
            }
            
            return true;
            
        } catch (\Exception $e) {
            Log::error('ARCaptcha verification error', ['error' => $e->getMessage()]);
            return false;
        }
    }
}


// app/Http/Requests/ContactRequest.php
namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Rules\Arcaptcha;

class ContactRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }
    
    public function rules()
    {
        return [
            'name' => 'required|string|max:255',
            'email' => 'required|email',
            'message' => 'required|string|max:5000',
            'arcaptcha-token' => ['required', new Arcaptcha]
        ];
    }
    
    public function messages()
    {
        return [
            'arcaptcha-token.required' => 'Please complete the security check',
        ];
    }
}


// app/Rules/Arcaptcha.php
namespace App\Rules;

use Illuminate\Contracts\Validation\Rule;
use App\Services\ArcaptchaService;

class Arcaptcha implements Rule
{
    private $service;
    
    public function __construct()
    {
        $this->service = app(ArcaptchaService::class);
    }
    
    public function passes($attribute, $value)
    {
        return $this->service->verify($value);
    }
    
    public function message()
    {
        return 'CAPTCHA verification failed';
    }
}


// app/Http/Controllers/ContactController.php
namespace App\Http\Controllers;

use App\Http\Requests\ContactRequest;
use Illuminate\Http\JsonResponse;

class ContactController extends Controller
{
    public function store(ContactRequest $request): JsonResponse
    {
        // Validation (including CAPTCHA) already passed
        
        $validated = $request->validated();
        
        // Process contact form
        // ... your business logic here ...
        
        return response()->json([
            'success' => true,
            'message' => 'Message sent successfully'
        ]);
    }
}


// config/services.php
return [
    // ... other services ...
    
    'arcaptcha' => [
        'site_key' => env('ARCAPTCHA_SITE_KEY'),
        'secret_key' => env('ARCAPTCHA_SECRET_KEY'),
    ],
];


// routes/api.php
use App\Http\Controllers\ContactController;

Route::post('/contact', [ContactController::class, 'store']);


// .env
ARCAPTCHA_SITE_KEY=your_site_key_here
ARCAPTCHA_SECRET_KEY=your_secret_key_here
```

## Notes

- Use cURL or `file_get_contents()` with stream context for HTTP requests
- Store keys in environment variables or config files (not in code)
- Always validate user input in addition to CAPTCHA verification
- Use `filter_var()` for email validation
- Log verification failures for monitoring
- Handle timeout and network errors gracefully
- Return appropriate HTTP status codes
- Use HTTPS in production
- Consider PSR-7 HTTP message interfaces for modern PHP applications
