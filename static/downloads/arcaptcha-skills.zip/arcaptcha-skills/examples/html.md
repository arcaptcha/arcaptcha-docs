# ARCaptcha HTML Example

Use this as the simplest reference implementation.

```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>ARCaptcha Example</title>
    <script src="https://nwidget.arcaptcha.ir/1/api.js" async defer></script>
  </head>
  <body>
    <form action="/signup" method="POST">
      <input name="email" type="email" required />
      <input name="password" type="password" required />

      <div class="arcaptcha" data-site-key="YOUR_SITE_KEY"></div>

      <button type="submit">Sign up</button>
    </form>
  </body>
</html>
```

The backend receives `arcaptcha-token` and verifies it before creating the account.

Verification endpoint:

```text
POST https://api.arcaptcha.co/arcaptcha/api/verify
```
